"""Smart Validation Tool for SDTM/ADaM/TFL pre-delivery QC."""
__version__ = "0.2.4"
__all__ = []
