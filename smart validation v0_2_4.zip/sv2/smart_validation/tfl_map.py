from __future__ import annotations
from pathlib import Path
import re
import pandas as pd

_OUTPUT_EXTS_DEFAULT = [".pdf", ".rtf", ".out", ".xlsx"]

# ---------------------------------------------------------------------------
# Patterns for extracting output file names from SAS LOG files
# ---------------------------------------------------------------------------
_LOG_PATTERNS_DEFAULT = [
    # 1. Footnote: "Output file: name.pdf"
    r"(?i)output\s+file\s*[:\s]+([A-Za-z0-9._-]+\.(?:pdf|rtf|out|xlsx))",
    # 2. ODS NOTE messages
    r"(?i)NOTE:\s+(?:Writing|ODS\s+is\s+closing\s+the\s+file)[^\n]*?([A-Za-z0-9._-]+\.(?:pdf|rtf|out|xlsx))",
    # 3. ODS/filename statement echoed in log
    r"(?i)(?:ods\s+\w+\s+file\s*=\s*['\"]|filename\s+\w+\s+['\"])([A-Za-z0-9._/\\-]+\.(?:pdf|rtf|out|xlsx))['\"]",
    # 4. Broad fallback: TFL-like token ending in known ext
    r"(?i)\b([A-Za-z][A-Za-z0-9_-]*(?:-[A-Za-z0-9_]+)*\.(?:pdf|rtf|out))\b",
]

# ---------------------------------------------------------------------------
# Patterns for extracting output file names from SAS SOURCE (.sas) files
# Broader set to catch: ODS statements, filename statements, macro params,
# footnote/title references, and %macro calls - covers case when logs absent
# ---------------------------------------------------------------------------
_SAS_SOURCE_PATTERNS = [
    # "Output file: name.ext" in footnote/comment
    re.compile(r"(?i)output\s+file\s*[:\s]+([A-Za-z0-9._-]+\.(?:pdf|rtf|out|xlsx))"),
    # "name.ext" or 'name.ext' as any quoted string literal
    re.compile(r"""(?i)['"]([ A-Za-z][A-Za-z0-9_-]*(?:-[A-Za-z0-9_]+)*\.(?:pdf|rtf|out|xlsx))['"]"""),
    # outname=name or output_name=name (macro parameter, unquoted)
    re.compile(r"(?i)(?:outname|outfile|output_name)\s*=\s*([A-Za-z][A-Za-z0-9_-]*(?:-[A-Za-z0-9_]+)+)(?=[,\s);])"),
]


def _cfg_list(cfg, section: str, key: str, default: list) -> list:
    try:
        val = cfg.get(section, key, default=default)
        if isinstance(val, list) and val:
            return val
        return list(default)
    except Exception:
        return list(default)


def _compile_log_patterns(cfg) -> list:
    raw = _cfg_list(cfg, "tfl", "log_output_patterns", default=_LOG_PATTERNS_DEFAULT)
    compiled = []
    for p in raw:
        try:
            compiled.append(re.compile(p))
        except re.error:
            pass
    return compiled or [re.compile(p) for p in _LOG_PATTERNS_DEFAULT]


def _output_exts(cfg) -> list:
    exts = _cfg_list(cfg, "tfl", "output_exts", default=_OUTPUT_EXTS_DEFAULT)
    return [e.lower() for e in exts]


def _read_lines(path: Path, nmax: int = 20000):
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for i, line in enumerate(f):
                if i >= nmax:
                    break
                yield line.rstrip("\n")
    except Exception:
        return


def _read_all(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


def _extract_fname_from_match(m: re.Match, exts: list) -> str:
    """Extract and validate a filename from a regex match object."""
    for i in range(1, (m.lastindex or 0) + 1):
        g = m.group(i)
        if g and any(g.lower().endswith(e) for e in exts):
            return Path(g).name
    text = m.group(0) or ""
    for ext in exts:
        m2 = re.search(r"(?i)\b([A-Za-z0-9._-]+" + re.escape(ext) + r")\b", text)
        if m2:
            return m2.group(1)
    return ""


def _stem(name: str) -> str:
    """Lowercase filename stem without extension."""
    if not name:
        return ""
    return re.sub(r"\.[^.\\/:]+$", "", name).lower()


def _normalize_output_stem(stem: str, val_prefixes=None) -> str:
    """
    Strip val prefix from an output stem so val and prod outputs match.
    Val programs produce outputs with v- prefix (v-g-pkconc-14c-ams-ind1.pdf)
    while prod produces the same output without prefix (g-pkconc-14c-ams-ind1.pdf).
    Normalizing to the same stem enables correct outer-join pairing.
    """
    if val_prefixes is None:
        val_prefixes = ["v-", "v_"]
    low = stem.lower()
    for pfx in val_prefixes:
        if low.startswith(pfx.lower()):
            return stem[len(pfx):]
    return stem


def _prefix_match(output_stem: str, prog_list: list) -> str:
    """Match an output stem to a program by longest common prefix."""
    best = ""
    best_len = 0
    for prog in prog_list:
        p_low = prog.lower()
        if output_stem.startswith(p_low) and len(p_low) > best_len:
            best = prog
            best_len = len(p_low)
    return best


def _scan_sas_source(sas_path: Path, exts: list) -> set:
    """
    Scan a SAS source file for ALL output file/name references.
    Returns a set of output stems found.

    Catches:
    - footnote "Output file: name.pdf"
    - ods pdf file='name.pdf'
    - filename outfile 'name.pdf'
    - %macro_call(outname=name-of-output)
    - Any quoted string 'name.ext' or "name.ext"
    """
    stems = set()
    text = _read_all(sas_path)
    if not text:
        return stems
    for line in text.splitlines():
        for pat in _SAS_SOURCE_PATTERNS:
            for m in pat.finditer(line):
                raw = m.group(1).strip().rstrip('";').strip()
                # Check if it has a known extension
                if any(raw.lower().endswith(e) for e in exts):
                    s = _stem(raw)
                    if s and len(s) > 3:
                        stems.add(s)
                else:
                    # Bare name from macro param - keep if looks like a TFL output name
                    # (contains at least one hyphen and >5 chars = not a generic word)
                    if "-" in raw and len(raw) > 5:
                        stems.add(raw.lower())
    return stems


def _build_side_map(
    df_logs: pd.DataFrame,
    side: str,
    cfg,
    disk_outputs: pd.DataFrame = None,
    sas_files: pd.DataFrame = None,
) -> pd.DataFrame:
    """
    Build output_stem -> program mapping for one side (prod or valid).

    Priority order:
      1. LOG file:    "Output file: xxx.pdf", ODS NOTE, ODS statement
      2. SAS source:  ALL string literals, ODS statements, macro params
      3. Disk:        match .pdf/.rtf files to programs by longest prefix
    """
    prog_col = "{}_program".format(side)
    out_col  = "{}_output".format(side)
    empty_cols = [prog_col, out_col, "output_stem"]
    empty = pd.DataFrame(columns=empty_cols)

    log_patterns = _compile_log_patterns(cfg)
    exts = _output_exts(cfg)

    rows = []
    seen = set()  # (prog, stem) dedup

    # ---- Strategy 1-3: scan LOG files ----
    logs_ok = df_logs is not None and not df_logs.empty
    if logs_ok:
        for col in ("program_name", "file_path"):
            if col not in df_logs.columns:
                logs_ok = False
                break

    if logs_ok:
        for _, r in df_logs.iterrows():
            log_path = Path(r["file_path"])
            prog = r["program_name"]
            for line in _read_lines(log_path):
                for pat in log_patterns:
                    m = pat.search(line)
                    if not m:
                        continue
                    fname = _extract_fname_from_match(m, exts)
                    if not fname:
                        continue
                    st = _stem(fname)
                    # Normalize val output stems so they match prod stems in the merge
                    if side == "valid":
                        st = _normalize_output_stem(st)
                    key = (prog, st)
                    if key not in seen:
                        seen.add(key)
                        rows.append({prog_col: prog, out_col: fname, "output_stem": st})
                    break

    # ---- Strategy 4: scan SAS SOURCE files (comprehensive) ----
    # Always run this - fills gaps when logs are absent or incomplete
    if sas_files is not None and not sas_files.empty:
        for _, r in sas_files.iterrows():
            prog = r["program_name"]
            sas_path = Path(r["file_path"])
            stems = _scan_sas_source(sas_path, exts)
            for st in stems:
                # Normalize val output stems (strip v- prefix)
                if side == "valid":
                    st = _normalize_output_stem(st)
                key = (prog, st)
                if key not in seen:
                    seen.add(key)
                    rows.append({prog_col: prog, out_col: st, "output_stem": st})

    # ---- Strategy 5: disk fallback ----
    if not rows and disk_outputs is not None and not disk_outputs.empty:
        prog_list = []
        if logs_ok and "program_name" in df_logs.columns:
            prog_list = df_logs["program_name"].tolist()
        elif sas_files is not None and not sas_files.empty and "program_name" in sas_files.columns:
            prog_list = sas_files["program_name"].tolist()
        for _, r in disk_outputs.iterrows():
            fname = r["filename"]
            st = _stem(fname)
            matched = _prefix_match(st, prog_list)
            if matched:
                key = (matched, st)
                if key not in seen:
                    seen.add(key)
                    rows.append({prog_col: matched, out_col: fname, "output_stem": st})

    if not rows:
        return empty

    df = pd.DataFrame(rows)
    return (
        df.sort_values([prog_col, "output_stem"])
        .drop_duplicates([prog_col, "output_stem"])
        .reset_index(drop=True)
    )


def tfl_pairs(
    prod_logs: pd.DataFrame,
    val_logs: pd.DataFrame,
    prod_out: pd.DataFrame,
    val_out: pd.DataFrame,
    cfg,
    prod_sas: pd.DataFrame = None,
    val_sas: pd.DataFrame = None,
) -> pd.DataFrame:
    """
    Build PROD <-> VALID pairing keyed on output_stem.

    For each output file, finds which prod program and which val program
    produced/validated it - even when val logs do not yet exist.

    Columns: [output_stem, prod_program, prod_output, valid_program, valid_output]
    """
    canonical = ["output_stem", "prod_program", "prod_output", "valid_program", "valid_output"]
    empty = pd.DataFrame(columns=canonical)

    prod_map = _build_side_map(
        prod_logs if prod_logs is not None else pd.DataFrame(),
        "prod", cfg,
        disk_outputs=prod_out,
        sas_files=prod_sas,
    )
    valid_map = _build_side_map(
        val_logs if val_logs is not None else pd.DataFrame(),
        "valid", cfg,
        disk_outputs=val_out,
        sas_files=val_sas,
    )

    if not prod_map.empty and not valid_map.empty:
        pairs = prod_map.merge(valid_map, on="output_stem", how="outer")
    elif not prod_map.empty:
        pairs = prod_map.copy()
    elif not valid_map.empty:
        pairs = valid_map.copy()
    else:
        return empty

    for col in canonical:
        if col not in pairs.columns:
            pairs[col] = pd.NA

    # Remove any output_stem rows that still start with val prefix
    # (spurious rows from val .sas referencing other val program names)
    val_pfx_list = ["v-", "v_"]

    def _is_val_stem(s):
        s_low = str(s).lower()
        return any(s_low.startswith(p) for p in val_pfx_list)

    if not pairs.empty and "output_stem" in pairs.columns:
        pairs = pairs[~pairs["output_stem"].apply(_is_val_stem)].copy()

    return (
        pairs[canonical]
        .sort_values(["output_stem", "prod_program", "valid_program"], na_position="last")
        .drop_duplicates(["output_stem", "prod_program", "valid_program"])
        .reset_index(drop=True)
    )
