from __future__ import annotations
from pathlib import Path
from datetime import datetime
import pandas as pd
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ---------------------------------------------------------------------------
# Status -> Excel fill colour (hex, no #)
# Severity tiers:
#   Dark red  : Independence Violation
#   Red       : Critical errors, missing programs, comparison differences
#   Orange    : Compare Not Run (regulatory gap - validation not performed)
#   Amber     : Timing issues, modified-after-run
#   Blue      : Warnings Found (informational SAS warnings)
#   Teal      : Helper - no validation required
#   Green     : OK, Active, Clean, Present, Current
# NO duplicate keys - Python silently drops the first of any duplicate.
# ---------------------------------------------------------------------------
_STATUS_COLORS = {
    "OK":                              "C6EFCE",
    "ACTIVE":                          "C6EFCE",
    "CURRENT":                         "C6EFCE",
    "CLEAN":                           "C6EFCE",
    "PRESENT":                         "C6EFCE",
    "Helper - No Validation Required": "DDFFFF",
    "Warnings Found":                  "BDD7EE",
    "Prod Modified After Run":         "FFEB9C",
    "Val Modified After Run":          "FFEB9C",
    "Run Order Issue":                 "FFEB9C",
    "Timing Issue":                    "FFEB9C",
    "OUTDATED":                        "FFEB9C",
    "NOT RUN":                         "FFEB9C",
    "EMPTY":                           "FFEB9C",
    "EXTRA":                           "FFEB9C",
    "UNKNOWN":                         "FFEB9C",
    "Compare Not Run":                 "FCE4D6",
    "Val Output Missing":              "FCE4D6",
    "Comparison Differences":          "FFC7CE",
    "Critical Log Error":              "FFC7CE",
    "Critical Issues Found":           "FFC7CE",
    "DIFFERENCES":                     "FFC7CE",
    "Missing Production Program":      "FFC7CE",
    "Missing Validation Program":      "FFC7CE",
    "MISSING":                         "FFC7CE",
    "Independence Violation":          "FF9999",
    "VIOLATION":                       "FF9999",
}

_STATUS_FONT_COLORS = {
    "OK":                              "155724",
    "ACTIVE":                          "155724",
    "CURRENT":                         "155724",
    "CLEAN":                           "155724",
    "PRESENT":                         "155724",
    "Helper - No Validation Required": "0C5460",
    "Warnings Found":                  "004085",
    "Prod Modified After Run":         "856404",
    "Val Modified After Run":          "856404",
    "Run Order Issue":                 "856404",
    "Timing Issue":                    "856404",
    "OUTDATED":                        "856404",
    "NOT RUN":                         "856404",
    "EMPTY":                           "856404",
    "EXTRA":                           "856404",
    "UNKNOWN":                         "856404",
    "Compare Not Run":                 "7B3F00",
    "Val Output Missing":              "7B3F00",
    "Comparison Differences":          "721C24",
    "Critical Log Error":              "721C24",
    "Critical Issues Found":           "721C24",
    "DIFFERENCES":                     "721C24",
    "Missing Production Program":      "721C24",
    "Missing Validation Program":      "721C24",
    "MISSING":                         "721C24",
    "Independence Violation":          "8B0000",
    "VIOLATION":                       "8B0000",
}

# Human-readable column labels for Excel output
_COL_LABELS = {
    "program_name":       "Program / Output",
    "domain":             "Domain",
    "prod_program":       "Prod Program",
    "val_program":        "Val Program",
    "full_name_prod":     "Prod Programmer",
    "userid_prod":        "Prod UserID",
    "full_name_valid":    "Val Programmer",
    "userid_valid":       "Val UserID",
    "independence":       "Independence",
    "prod_modify_time":   "Prod Modified",
    "valid_modify_time":  "Val Modified",
    "prod_run_time":      "Prod Run Time",
    "valid_run_time":     "Val Run Time",
    "error_count":        "Errors",
    "warning_count":      "Warnings",
    "compare_status":     "Compare Status",
    "overall_status":     "Overall Status",
    "is_helper":          "Helper Flag",
    "prod_output_exists": "Prod Output File",
    "val_output_exists":  "Val Output File",
    "file_path_prod":     "Prod File Path",
    "file_path_valid":    "Val File Path",
    "issue_type":         "Issue Type",
    "issue_text":         "Issue Description",
    "file_path":          "File",
    "source":             "Source",
    "path_type":          "Path Type",
    "path_value":         "Path",
    "status":             "Status",
    "titlekey":           "Title Key",
    "tflt":               "Type (T/L/G)",
    "tfln":               "TFL Number",
    "title1":             "Description",
    "matched_outputs":    "Matched Outputs",
    "tnf_file":           "TNF File Used",
    "modify_time":        "Modified",
    "details":            "Details",
}

# Column order for domain sheets (internal names)
_SDTM_ADAM_COLS = [
    "program_name", "prod_program", "val_program",
    "full_name_prod", "userid_prod",
    "full_name_valid", "userid_valid",
    "overall_status", "independence",
    "prod_modify_time", "valid_modify_time",
    "prod_run_time", "valid_run_time",
    "compare_status", "error_count", "warning_count",
]

_TFL_COLS = [
    "program_name", "prod_program", "val_program",
    "full_name_prod", "userid_prod",
    "full_name_valid", "userid_valid",
    "overall_status", "independence",
    "prod_run_time", "valid_run_time",
    "prod_output_exists", "val_output_exists",
    "compare_status", "error_count", "warning_count",
]

_THIN = Side(style="thin", color="CCCCCC")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)


def _strip_tz(df):
    """Remove timezone from datetime cols - Excel requires tz-naive datetimes."""
    if df is None or df.empty:
        return df
    out = df.copy()
    for col in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[col]):
            try:
                out[col] = out[col].dt.tz_convert(None)
            except Exception:
                try:
                    out[col] = out[col].dt.tz_localize(None)
                except Exception:
                    pass
    return out


def _rename_cols(df: pd.DataFrame) -> pd.DataFrame:
    """Rename DataFrame columns to human-readable labels for Excel."""
    return df.rename(columns={k: v for k, v in _COL_LABELS.items() if k in df.columns})


def _stem_only(fp: str) -> str:
    """Return just the filename stem (no path, no extension)."""
    import re
    if not fp or str(fp) in ("", "nan", "--"):
        return "--"
    parts = re.split(r"[/\\]", str(fp))
    filename = next((p for p in reversed(parts) if p), "")
    if not filename:
        return "--"
    dot = filename.rfind(".")
    return filename[:dot] if dot > 0 else filename


def _fmt_dt(val) -> str:
    """Format timestamp to clinical SAS-style string: 15JAN2025 14:30."""
    try:
        if pd.isna(val):
            return "--"
        return pd.Timestamp(val).strftime("%d%b%Y %H:%M").upper()
    except Exception:
        return str(val)[:19] if val else "--"


def _autosize(ws, max_width: int = 55):
    dims = {}
    for row in ws.rows:
        for cell in row:
            if cell.value is not None:
                dims[cell.column] = max(dims.get(cell.column, 0), len(str(cell.value)))
    for col, width in dims.items():
        ws.column_dimensions[get_column_letter(col)].width = min(max_width, width + 3)


def _freeze_and_bold_header(ws, auto_filter: bool = True):
    ws.freeze_panes = "A2"
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
        cell.border = _BORDER
    ws.row_dimensions[1].height = 30
    if auto_filter and ws.max_row > 1:
        ws.auto_filter.ref = ws.dimensions


def _apply_row_colors(ws, status_col_label: str):
    """
    Apply full-row background and font colour based on status column value.
    Looks up the status column by its human-readable label.
    """
    header = {}
    for idx, cell in enumerate(next(ws.iter_rows(min_row=1, max_row=1))):
        if cell.value is not None:
            header[str(cell.value)] = idx + 1  # 1-based

    if status_col_label not in header:
        return

    status_idx = header[status_col_label]

    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        status_cell = row[status_idx - 1]
        val = str(status_cell.value) if status_cell.value is not None else ""
        bg = _STATUS_COLORS.get(val)
        fc = _STATUS_FONT_COLORS.get(val)
        for cell in row:
            cell.border = _BORDER
            if bg:
                cell.fill = PatternFill(start_color=bg, end_color=bg, fill_type="solid")
            if fc:
                is_status = (cell.column == status_idx)
                cell.font = Font(color=fc, bold=is_status)


def _select_and_prep_domain(fr: pd.DataFrame, dom: str, col_list: list) -> pd.DataFrame:
    """Filter to domain, select columns, shorten paths, format datetimes."""
    sub = fr[fr["domain"] == dom].copy() if not fr.empty else pd.DataFrame()
    if sub.empty:
        return sub

    for pc in ["prod_program", "val_program", "file_path_prod", "file_path_valid"]:
        if pc in sub.columns:
            sub[pc] = sub[pc].apply(_stem_only)

    for dc in ["prod_modify_time", "valid_modify_time", "prod_run_time", "valid_run_time"]:
        if dc in sub.columns:
            sub[dc] = sub[dc].apply(_fmt_dt)

    cols = [c for c in col_list if c in sub.columns]
    return _strip_tz(sub[cols])


def write_reports(outputs: dict, study, cfg) -> dict:
    """
    Write Excel, CSV, and HTML reports to study docs folder.
    Returns dict of written file paths.
    """
    docs = study.docs
    docs.mkdir(parents=True, exist_ok=True)

    ts = ""
    if cfg.get("reporting", "timestamp_in_filenames", default=True):
        ts = "_" + datetime.now().strftime("%Y%m%d_%H%M%S")

    written = {}

    # ------------------------------------------------------------------ Excel
    if cfg.get("reporting", "write_excel", default=True):
        xlsx = docs / "Validation_Report{}.xlsx".format(ts)
        with pd.ExcelWriter(xlsx, engine="openpyxl") as writer:

            # Summary first
            _write_summary_sheet(writer, outputs)

            # Paths Summary
            ps = _rename_cols(outputs["paths_summary"].copy())
            ps.to_excel(writer, index=False, sheet_name="Paths Summary")
            ws = writer.sheets["Paths Summary"]
            _freeze_and_bold_header(ws)
            _apply_row_colors(ws, "Status")
            _autosize(ws)

            # TNF Check
            tnf_chk = _rename_cols(outputs["tnf_check"].copy())
            tnf_chk.to_excel(writer, index=False, sheet_name="TNF Check")
            ws = writer.sheets["TNF Check"]
            _freeze_and_bold_header(ws)
            _apply_row_colors(ws, "Status")
            _autosize(ws)

            # Domain sheets
            fr = outputs["final_report"]
            for dom, col_list in [("SDTM", _SDTM_ADAM_COLS), ("ADAM", _SDTM_ADAM_COLS), ("TFL", _TFL_COLS)]:
                sub = _select_and_prep_domain(fr, dom, col_list)
                if not sub.empty:
                    _rename_cols(sub).to_excel(writer, index=False, sheet_name=dom)
                    ws = writer.sheets[dom]
                    _freeze_and_bold_header(ws)
                    _apply_row_colors(ws, "Overall Status")
                    _autosize(ws)

            # Log Issues (deduplicated with counts)
            iss_src = outputs.get("issues_summary") 
            if iss_src is None or iss_src.empty:
                iss_src = outputs["all_issues"]
            iss = _rename_cols(_strip_tz(iss_src.copy()))
            iss.to_excel(writer, index=False, sheet_name="Log Issues")
            ws = writer.sheets["Log Issues"]
            _freeze_and_bold_header(ws)
            _apply_row_colors(ws, "Issue Type")
            _autosize(ws)

            # TFL Pairs
            if not outputs["tfl_pairs"].empty:
                _strip_tz(outputs["tfl_pairs"]).to_excel(writer, index=False, sheet_name="TFL Pairs")
                ws = writer.sheets["TFL Pairs"]
                _freeze_and_bold_header(ws)
                _autosize(ws)

            # Tools Programs
            if not outputs["programs_tools"].empty:
                tp = outputs["programs_tools"].copy()
                if "modify_time" in tp.columns:
                    tp["modify_time"] = tp["modify_time"].apply(_fmt_dt)
                _rename_cols(_strip_tz(tp)).to_excel(writer, index=False, sheet_name="Tools Programs")
                ws = writer.sheets["Tools Programs"]
                _freeze_and_bold_header(ws)
                _autosize(ws)

            # TNF Coverage
            tnf_cov = outputs.get("tnf_coverage")
            if tnf_cov is not None and not tnf_cov.empty:
                _rename_cols(_strip_tz(tnf_cov.copy())).to_excel(
                    writer, index=False, sheet_name="TNF Coverage"
                )
                ws = writer.sheets["TNF Coverage"]
                _freeze_and_bold_header(ws)
                _apply_row_colors(ws, "Status")
                _autosize(ws)

            # Orphan Outputs (TFL outputs with no matching program)
            orphans = outputs.get("orphan_outputs")
            if orphans is not None and not orphans.empty:
                orph_display = orphans.copy()
                if "file_path" in orph_display.columns:
                    orph_display["file_path"] = orph_display["file_path"].apply(_stem_only)
                _rename_cols(orph_display).to_excel(
                    writer, index=False, sheet_name="Orphan Outputs"
                )
                ws = writer.sheets["Orphan Outputs"]
                _freeze_and_bold_header(ws)
                _autosize(ws)

        written["excel"] = xlsx

    # ------------------------------------------------------------------ CSV
    if cfg.get("reporting", "write_csv", default=True):
        fr_csv     = docs / "final_report{}.csv".format(ts)
        issues_csv = docs / "issues{}.csv".format(ts)
        if not outputs["final_report"].empty:
            outputs["final_report"].to_csv(fr_csv, index=False)
            written["final_csv"] = fr_csv
        outputs["all_issues"].to_csv(issues_csv, index=False)
        written["issues_csv"] = issues_csv

    # ------------------------------------------------------------------ HTML
    if cfg.get("reporting", "write_html", default=True):
        html_path = docs / "Validation_Report{}.html".format(ts)
        _write_html_report(outputs, study, html_path)
        written["html"] = html_path

    return written


def _write_summary_sheet(writer, outputs: dict):
    fr = outputs["final_report"]
    if fr.empty:
        return

    total    = len(fr)
    ok_n     = int((fr["overall_status"] == "OK").sum())
    crit_n   = int(fr["overall_status"].isin([
        "Critical Log Error", "Comparison Differences"
    ]).sum())
    indep_n  = int((fr["overall_status"] == "Independence Violation").sum())
    cmp_nr_n = int((fr["overall_status"] == "Compare Not Run").sum())
    miss_n   = int(fr["overall_status"].isin([
        "Missing Production Program", "Missing Validation Program"
    ]).sum())
    timing_n = int(fr["overall_status"].isin([
        "Prod Modified After Run", "Val Modified After Run", "Run Order Issue"
    ]).sum())
    warn_n   = int((fr["overall_status"] == "Warnings Found").sum())
    helper_n = int((fr["overall_status"] == "Helper - No Validation Required").sum())

    compare_clean = compare_diff = compare_nr = 0
    if "compare_status" in fr.columns:
        compare_clean = int((fr["compare_status"] == "CLEAN").sum())
        compare_diff  = int((fr["compare_status"] == "DIFFERENCES").sum())
        compare_nr    = int((fr["compare_status"] == "NOT RUN").sum())

    # Completeness per domain
    completeness = outputs.get("completeness", {})
    def _comp_str(dom):
        c = completeness.get(dom, {})
        if not c or c.get("total", 0) == 0:
            return "N/A"
        return "{}/{} ({}%)".format(c["complete"], c["total"], c["pct"])

    # Attention score: any non-OK, non-helper items needing review
    attention_n = total - ok_n - helper_n

    rows = [
        ["Metric",                           "Count", "Notes"],
        ["Total Programs / Outputs",         total,   "All domains combined (SDTM + ADaM + TFL)"],
        ["--- Completeness by Domain ---",    "",      "Programs with paired val + no log errors"],
        ["SDTM Completeness",                 _comp_str("SDTM"), "paired + no errors / total SDTM"],
        ["ADaM Completeness",                 _comp_str("ADAM"), "paired + no errors / total ADaM"],
        ["TFL Completeness",                  _comp_str("TFL"),  "paired + no errors / total TFL"],
        ["OK - All Checks Pass",             ok_n,    "No issues found"],
        ["Requires Attention",               attention_n, "Any non-OK, non-helper program"],
        ["--- Critical Issues ---",          "",      ""],
        ["Critical Errors / Compare Diff",   crit_n,  "SAS log errors or PROC COMPARE differences found"],
        ["Independence Violations",          indep_n, "Prod and val programmer are the same person"],
        ["Missing Programs",                 miss_n,  "Production or validation program is absent"],
        ["--- Regulatory Gap ---",           "",      ""],
        ["Compare Not Run",                  cmp_nr_n,"PROC COMPARE not executed - validation incomplete"],
        ["--- Advisory ---",                 "",      ""],
        ["Timing Issues",                    timing_n,"Modified after run, or run order mismatch"],
        ["Warnings Found",                   warn_n,  "SAS log warnings present (review recommended)"],
        ["Helpers (No Val Required)",        helper_n,"Utility/macro programs exempt from validation"],
        ["--- PROC Compare Detail ---",      "",      ""],
        ["PROC Compare Clean",               compare_clean, "No differences found"],
        ["PROC Compare Differences",         compare_diff,  "Differences found between prod and val outputs"],
        ["PROC Compare Not Run",             compare_nr,    "Compare not executed for this program"],
    ]

    df_summary = pd.DataFrame(rows[1:], columns=rows[0])
    df_summary.to_excel(writer, index=False, sheet_name="Summary")
    ws = writer.sheets["Summary"]
    _freeze_and_bold_header(ws)

    _summary_row_colors = {
        "SDTM Completeness":              ("DDEEFF", "003366"),
        "ADaM Completeness":              ("DDEEFF", "003366"),
        "TFL Completeness":               ("DDEEFF", "003366"),
        "OK - All Checks Pass":           ("C6EFCE", "155724"),
        "Requires Attention":             ("FFF2CC", "7F6000"),
        "Critical Errors / Compare Diff": ("FFC7CE", "721C24"),
        "Independence Violations":        ("FF9999", "8B0000"),
        "Missing Programs":               ("FFC7CE", "721C24"),
        "Compare Not Run":                ("FCE4D6", "7B3F00"),
        "Timing Issues":                  ("FFEB9C", "856404"),
        "Warnings Found":                 ("BDD7EE", "004085"),
        "PROC Compare Clean":             ("C6EFCE", "155724"),
        "PROC Compare Differences":       ("FFC7CE", "721C24"),
        "PROC Compare Not Run":           ("FCE4D6", "7B3F00"),
    }

    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        metric_val = str(row[0].value) if row[0].value else ""
        pair = _summary_row_colors.get(metric_val)
        for cell in row:
            cell.border = _BORDER
            if pair:
                bg, fc = pair
                cell.fill = PatternFill(start_color=bg, end_color=bg, fill_type="solid")
                cell.font = Font(color=fc, bold=(cell.column == 1))
            elif metric_val.startswith("---"):
                # Section divider rows - grey italic
                cell.font = Font(color="595959", italic=True)
                cell.fill = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")

    _autosize(ws)


def _write_html_report(outputs: dict, study, path: Path):
    """Generate a standalone interactive HTML report."""
    from smart_validation.html_report import build_html
    html = build_html(outputs, study)
    path.write_text(html, encoding="utf-8")
