from __future__ import annotations
from pathlib import Path
from typing import List
import re
import pandas as pd

_EMPTY_COLS = [
    "file_path", "filename", "ext", "filetype",
    "program_name", "domain", "mtime", "size", "label",
]


def is_hidden(path: Path) -> bool:
    return any(
        part.startswith(".") or part.startswith("~$")
        for part in path.as_posix().split("/")
    )


def normalize_val_stem(name: str, val_prefixes: List[str]) -> str:
    """Strip validation prefix (e.g. v-, v_) from a program stem."""
    low = name.lower()
    for pfx in val_prefixes:
        if low.startswith(pfx.lower()):
            return name[len(pfx):]
    return name


def is_helper(stem: str, helper_suffixes: List[str], helper_programs: List[str]) -> bool:
    """Return True if this program is a known helper/utility with no validation counterpart."""
    low = stem.lower()
    for hp in helper_programs:
        if low == hp.lower().replace(".sas", ""):
            return True
    for sfx in helper_suffixes:
        if low.endswith(sfx.lower()):
            return True
    return False


def detect_domain(stem: str) -> str:
    """
    Infer SDTM / ADaM / TFL domain from program stem.
    TFL:  starts with t-, l-, g-, f- (table/listing/graph/figure)
    ADaM: starts with 'ad' followed by a letter or underscore
    SDTM: everything else
    """
    if re.search(r"^(?:l-|t-|g-|f-)", stem, flags=re.IGNORECASE):
        return "TFL"
    if re.search(r"^ad[a-z_]", stem, flags=re.IGNORECASE):
        return "ADAM"
    return "SDTM"


def scan_dir(
    dir_path: Path,
    include_exts: List[str],
    ignore_hidden: bool = True,
    label: str = "",
) -> pd.DataFrame:
    """
    Recursively scan dir_path for files matching include_exts.
    Returns a DataFrame with one row per file found.
    """
    rows = []
    if not dir_path.exists():
        return pd.DataFrame(columns=_EMPTY_COLS)

    seen = set()
    for ext in include_exts:
        for p in sorted(dir_path.rglob("*{}".format(ext))):
            rp = str(p.resolve())
            if rp in seen:
                continue
            seen.add(rp)
            if ignore_hidden and is_hidden(p):
                continue
            suffix = p.suffix.lower()
            if suffix == ".sas":
                ftype = "SAS"
            elif suffix == ".log":
                ftype = "LOG"
            elif suffix == ".lst":
                ftype = "LST"
            elif suffix in (".pdf", ".rtf", ".out", ".xlsx"):
                ftype = "OUT"
            else:
                ftype = "OTHER"
            stem = p.stem
            # Strip validation prefix before domain detection so
            # v-adsl -> ADAM (same as adsl), v-t-ae -> TFL, etc.
            _pfx = ["v-", "v_"]
            stem_for_domain = normalize_val_stem(stem, _pfx)
            rows.append(dict(
                file_path=rp,
                filename=p.name,
                ext=suffix,
                filetype=ftype,
                program_name=stem,
                domain=detect_domain(stem_for_domain),
                mtime=p.stat().st_mtime,
                size=p.stat().st_size,
                label=label,
            ))
    return pd.DataFrame(rows) if rows else pd.DataFrame(columns=_EMPTY_COLS)
