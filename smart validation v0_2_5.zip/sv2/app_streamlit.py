"""
Streamlit entry point.
Run with:
    streamlit run app_streamlit.py
    streamlit run app_streamlit.py --server.port 8501 --server.address 0.0.0.0
"""
from smart_validation.app import main

if __name__ == "__main__":
    main()
