from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict
import yaml


@dataclass
class Config:
    raw: Dict[str, Any]

    @classmethod
    def from_file(cls, path: str = "config.yaml") -> "Config":
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError("Config not found: {}".format(p))
        with p.open("r", encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}
        return cls(raw=raw)

    @classmethod
    def default(cls) -> "Config":
        """Return a Config with built-in defaults (no file needed)."""
        return cls(raw={})

    def get(self, *keys, default=None):
        cur = self.raw
        for k in keys:
            if not isinstance(cur, dict):
                return default
            cur = cur.get(k, default)
        return cur

    def validate(self) -> list:
        """Return list of warning strings for missing/unusual config keys."""
        warnings = []
        if not self.get("studies_root"):
            warnings.append("studies_root not set in config.yaml")
        return warnings
