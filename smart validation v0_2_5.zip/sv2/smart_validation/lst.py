from __future__ import annotations
from pathlib import Path
import re
import pandas as pd

_MISMATCH_RE  = re.compile(r"(?:Mismatch|DIFF|Difference)", re.I)
_UNMERGED_RE  = re.compile(r"unmerged.*observations", re.I)
_COMPARE_CLEAN = re.compile(r"No unequal values|0 variables have conflicting|all values are identical", re.I)
_COMPARE_DIFF  = re.compile(r"conflicting values|\d+\s+variable.*unequal", re.I)


def _read_lines(path: Path, nmax: int = 10000):
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for i, line in enumerate(f):
                if i >= nmax:
                    break
                yield line.rstrip("\n")
    except Exception:
        return


def analyze_lsts(df_lst: pd.DataFrame) -> pd.DataFrame:
    """
    Scan validation .lst files for mismatch/error patterns.

    Returns DataFrame with columns:
        [program_name, issue_type, issue_text, file_path, domain, source]
    """
    rows = []
    if df_lst is None or df_lst.empty:
        return pd.DataFrame(columns=["program_name", "issue_type", "issue_text", "file_path", "domain", "source"])

    for _, r in df_lst.iterrows():
        if r.get("label") != "valid":
            continue
        p = Path(r["file_path"])
        prog = r["program_name"]
        dom = r.get("domain", "")

        found_any = False
        for line in _read_lines(p):
            if _COMPARE_CLEAN.search(line):
                rows.append(dict(
                    program_name=prog, issue_type="COMPARE_CLEAN",
                    issue_text=line[:400].strip(), file_path=str(p),
                    domain=dom, source="VAL_LST",
                ))
                found_any = True
            elif _COMPARE_DIFF.search(line):
                rows.append(dict(
                    program_name=prog, issue_type="COMPARE_DIFF",
                    issue_text=line[:400].strip(), file_path=str(p),
                    domain=dom, source="VAL_LST",
                ))
                found_any = True
            elif _MISMATCH_RE.search(line) or _UNMERGED_RE.search(line):
                rows.append(dict(
                    program_name=prog, issue_type="MISMATCH",
                    issue_text=line[:400].strip(), file_path=str(p),
                    domain=dom, source="VAL_LST",
                ))
                found_any = True
            elif re.search(r"invalid numeric data", line, re.I):
                rows.append(dict(
                    program_name=prog, issue_type="ERROR",
                    issue_text="Invalid numeric data found",
                    file_path=str(p), domain=dom, source="VAL_LST",
                ))
                found_any = True
            elif re.search(r"division by zero", line, re.I):
                rows.append(dict(
                    program_name=prog, issue_type="ERROR",
                    issue_text="Division by zero detected",
                    file_path=str(p), domain=dom, source="VAL_LST",
                ))
                found_any = True

    return pd.DataFrame(rows) if rows else pd.DataFrame(
        columns=["program_name", "issue_type", "issue_text", "file_path", "domain", "source"]
    )
