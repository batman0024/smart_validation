from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Tuple


@dataclass
class StudyPaths:
    study_root: Path
    prod_sdtm: Path
    prod_adam: Path
    prod_tfl: Path
    valid: Path
    tools: Path
    docs: Path
    project_code: str
    study_code: str


def infer_project_study_from_path(path: Path) -> Tuple[str, str]:
    """
    Extract project and study codes from path.
    Handles deep structure: .../projects/p409/s4095696/final/draft1
    Returns (project_code, study_code) - e.g. ("p409", "s4095696")
    """
    parts_lower = [p.lower() for p in path.parts]
    parts_raw   = path.parts
    if "projects" in parts_lower:
        i = parts_lower.index("projects")
        proj = parts_raw[i + 1] if i + 1 < len(parts_raw) else ""
        stud = parts_raw[i + 2] if i + 2 < len(parts_raw) else ""
        return proj, stud
    # Fallback: walk back looking for s-prefixed study code
    for j in range(len(parts_raw) - 1, -1, -1):
        if parts_raw[j].lower().startswith("s") and len(parts_raw[j]) >= 5:
            proj = parts_raw[j - 1] if j > 0 else ""
            return proj, parts_raw[j]
    # Last resort
    if len(parts_raw) >= 2:
        return parts_raw[-2], parts_raw[-1]
    return "", str(path.name)


def get_full_path_label(path: Path) -> str:
    """
    Return a human-readable label showing project/study/task/version.
    e.g. "p409 / s4095696 / final / draft1"
    """
    parts_lower = [p.lower() for p in path.parts]
    parts_raw   = path.parts
    if "projects" in parts_lower:
        i = parts_lower.index("projects")
        segments = parts_raw[i + 1:]  # everything after 'projects'
        return " / ".join(segments)
    return path.name


def build_study_paths(cfg, study_root: Path) -> StudyPaths:
    L = cfg.get("layout", default={}) or {}
    prod_sdtm = study_root / L.get("prod_sdtm_dir", "sdtmprog")
    prod_adam = study_root / L.get("prod_adam_dir", "adamprog")
    prod_tfl  = study_root / L.get("prod_tfl_dir",  "prog")
    valid     = study_root / L.get("valid_dir",      "validation")
    tools     = study_root / L.get("tools_dir",      "tools")
    docs      = study_root / L.get("docs_dir",       "docs")
    proj, stud = infer_project_study_from_path(study_root)
    return StudyPaths(
        study_root=study_root,
        prod_sdtm=prod_sdtm,
        prod_adam=prod_adam,
        prod_tfl=prod_tfl,
        valid=valid,
        tools=tools,
        docs=docs,
        project_code=proj,
        study_code=stud,
    )
