from __future__ import annotations
from pathlib import Path
import re
import pandas as pd

_OUTPUT_EXTS_DEFAULT = [".pdf", ".rtf", ".out", ".xlsx"]

# ---------------------------------------------------------------------------
# Log patterns - extract output filenames from SAS log
# Applied line-by-line; all matches on every line are captured (one-to-many)
# ---------------------------------------------------------------------------
_LOG_PATTERNS_DEFAULT = [
    # ODS closing / writing NOTE (most reliable)
    r"(?i)NOTE:\s*(?:Writing|Closing|ODS\s+is\s+closing)[^\n]*?([A-Za-z][A-Za-z0-9._-]*\.(?:pdf|rtf|out|xlsx))",
    # ODS statement in log echo: ods pdf file='name.pdf'
    r"(?i)ods\s+\w+\s+file\s*=\s*['\"]([A-Za-z0-9._/\\-]+\.(?:pdf|rtf|out|xlsx))['\"]",
    # filename statement: filename outfile 'name.pdf'
    r"(?i)filename\s+\w+\s+['\"]([A-Za-z0-9._/\\-]+\.(?:pdf|rtf|out|xlsx))['\"]",
    # Footnote pattern: "Output file: name.pdf"
    r"(?i)output\s+file\s*[:\s]+([A-Za-z0-9._-]+\.(?:pdf|rtf|out|xlsx))",
    # Broad TFL-like token (fallback - catches anything that looks like output name)
    r"(?i)\b([A-Za-z][A-Za-z0-9_-]*(?:-[A-Za-z0-9_]+)+\.(?:pdf|rtf|out))\b",
]

# ---------------------------------------------------------------------------
# SAS source patterns - broader set, used when log is absent
# ---------------------------------------------------------------------------
_SAS_SOURCE_PATTERNS = [
    # Quoted string with known extension
    re.compile(r"""(?i)['"]([ A-Za-z][A-Za-z0-9_-]*(?:-[A-Za-z0-9_]+)*\.(?:pdf|rtf|out|xlsx))['"]"""),
    # ODS statement: ods pdf file=name.pdf or ods rtf file="name.rtf"
    re.compile(r"(?i)ods\s+\w+\s+file\s*=\s*['\"]?([A-Za-z][A-Za-z0-9._/-]+\.(?:pdf|rtf|out|xlsx))['\"]?"),
    # filename / file= parameter
    re.compile(r"(?i)filename\s+\w+\s+['\"]([A-Za-z0-9._/\\-]+\.(?:pdf|rtf|out|xlsx))['\"]"),
    # macro param: outname=t-ae-sum or outfile=t-ae-sum.rtf
    re.compile(r"(?i)(?:outname|outfile|output_name|outfn|out_file)\s*=\s*['\"]?([A-Za-z][A-Za-z0-9_-]*(?:-[A-Za-z0-9_]+)+(?:\.(?:pdf|rtf|out|xlsx))?)['\"]?"),
    # Output file footnote in SAS comment
    re.compile(r"(?i)\*\s*output\s+file\s*[:\s]+([A-Za-z0-9._-]+\.(?:pdf|rtf|out|xlsx))"),
]

# Noise tokens that look like output names but are not
_NOISE_TOKENS = {
    "style", "template", "width", "height", "margin", "landscape", "portrait",
    "body", "results", "output", "print", "nodate", "nonumber", "noproctitle",
}


def _cfg_list(cfg, section: str, key: str, default: list) -> list:
    try:
        val = cfg.get(section, key, default=default)
        if isinstance(val, list) and val:
            return val
        return list(default)
    except Exception:
        return list(default)


def _compile_log_patterns(cfg) -> list:
    raw = _cfg_list(cfg, "tfl", "log_output_patterns", default=_LOG_PATTERNS_DEFAULT)
    compiled = []
    for p in raw:
        try:
            compiled.append(re.compile(p))
        except re.error:
            pass
    # Always include compiled defaults as fallback
    for p in _LOG_PATTERNS_DEFAULT:
        try:
            compiled.append(re.compile(p))
        except re.error:
            pass
    # Deduplicate by pattern string
    seen = set()
    out = []
    for c in compiled:
        if c.pattern not in seen:
            seen.add(c.pattern)
            out.append(c)
    return out


def _output_exts(cfg) -> list:
    exts = _cfg_list(cfg, "tfl", "output_exts", default=_OUTPUT_EXTS_DEFAULT)
    return [e.lower() for e in exts]


def _read_lines(path: Path, nmax: int = 30000):
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for i, line in enumerate(f):
                if i >= nmax:
                    break
                yield line.rstrip("\n")
    except Exception:
        return


def _stem(name: str) -> str:
    """Lowercase filename stem without extension."""
    if not name:
        return ""
    return re.sub(r"\.[^.\\/: ]+$", "", name.strip()).lower().strip()


def _is_valid_output_stem(s: str, exts: list) -> bool:
    """
    Return True if this looks like a genuine TFL output name.
    Must contain a hyphen (TFL naming convention) and not be a noise token.
    """
    if not s or len(s) < 4:
        return False
    s_low = s.lower().rstrip(".,;\"'")
    # Strip extension if present
    for ext in exts:
        if s_low.endswith(ext):
            s_low = s_low[: -len(ext)]
            break
    if s_low in _NOISE_TOKENS:
        return False
    # Must contain at least one hyphen (TFL convention: t-ae-sum, l-lb-eff-saf)
    if "-" not in s_low:
        return False
    # Must start with a letter
    if not s_low[0].isalpha():
        return False
    # Minimum meaningful length
    if len(s_low) < 5:
        return False
    return True


def _normalize_output_stem(stem: str, val_prefixes=None) -> str:
    """Strip val prefix from output stem so prod and val outputs align."""
    if val_prefixes is None:
        val_prefixes = ["v-", "v_"]
    low = stem.lower()
    for pfx in val_prefixes:
        if low.startswith(pfx.lower()):
            return stem[len(pfx):]
    return stem


def _extract_stems_from_log(log_path: Path, patterns: list, exts: list) -> list:
    """
    Extract ALL output stems mentioned in a single SAS log file.
    Returns list of (stem, raw_filename) tuples - one program can have many outputs.
    """
    results = []
    seen_stems = set()

    for line in _read_lines(log_path):
        stripped = line.strip()
        if not stripped:
            continue
        for pat in patterns:
            for m in pat.finditer(line):
                for g_idx in range(1, (m.lastindex or 0) + 1):
                    g = m.group(g_idx)
                    if not g:
                        continue
                    raw = Path(g).name.strip()
                    st = _stem(raw)
                    if not _is_valid_output_stem(st, exts):
                        continue
                    if st not in seen_stems:
                        seen_stems.add(st)
                        results.append((st, raw))

    return results


def _extract_stems_from_sas(sas_path: Path, exts: list) -> list:
    """
    Extract ALL output stems mentioned in a SAS source file.
    Returns list of (stem, raw) tuples.
    """
    results = []
    seen_stems = set()
    try:
        text = sas_path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return results

    for line in text.splitlines():
        # Skip pure comment lines that are just section headers
        stripped = line.strip()
        if stripped.startswith("*") and len(stripped) < 20:
            continue
        for pat in _SAS_SOURCE_PATTERNS:
            for m in pat.finditer(line):
                raw = m.group(1).strip().rstrip('";,').strip()
                if not raw:
                    continue
                # If it has an extension check it's valid
                has_ext = any(raw.lower().endswith(e) for e in exts)
                if has_ext:
                    st = _stem(raw)
                else:
                    # Bare name from macro param
                    st = raw.lower()
                if not _is_valid_output_stem(st, exts):
                    continue
                if st not in seen_stems:
                    seen_stems.add(st)
                    results.append((st, raw))

    return results


def _shared_prefix_score(stem: str, prog: str) -> int:
    """
    Return the length of the shared prefix between output stem and program name.
    Used for fuzzy matching when exact log/source evidence is unavailable.
    e.g. 't-ae-summary-saf' vs 't-ae-summary' -> score 12
    """
    s = stem.lower()
    p = prog.lower()
    # Exact prefix match
    if s.startswith(p):
        return len(p)
    if p.startswith(s):
        return len(s)
    # Common prefix length
    common = 0
    for a, b in zip(s, p):
        if a == b:
            common += 1
        else:
            break
    return common


def _disk_match_output_to_prog(output_stem: str, prog_list: list) -> str:
    """
    Match output stem to best-fitting program by longest common prefix.
    Only returns a match if the program is a genuine prefix of the output
    (not just a short shared string).
    """
    best = ""
    best_score = 0
    for prog in prog_list:
        p_low = prog.lower()
        s_low = output_stem.lower()
        # Programme must be a true prefix of output stem
        if s_low.startswith(p_low) and len(p_low) > best_score:
            best = prog
            best_score = len(p_low)
    # Only use if at least 5 chars match (avoids spurious single-letter matches)
    return best if best_score >= 5 else ""


def _build_side_map(
    df_logs: pd.DataFrame,
    side: str,
    cfg,
    disk_outputs: pd.DataFrame = None,
    sas_files: pd.DataFrame = None,
) -> pd.DataFrame:
    """
    Build a one-to-many mapping: program -> [output_stem, ...] for one side.

    Strategy (in priority order, all applied and merged):
      1. LOG file scanning  - most reliable; finds ODS NOTE lines, filename echoes
      2. SAS source scanning - finds ODS/filename statements, macro params, quotes
      3. Disk prefix match  - fallback when no log or source evidence

    Returns DataFrame with columns: [prog_col, out_col, output_stem]
    where prog_col = 'prod_program' or 'valid_program'
    """
    prog_col = "{}_program".format(side)
    out_col  = "{}_output".format(side)
    empty_cols = [prog_col, out_col, "output_stem"]
    empty = pd.DataFrame(columns=empty_cols)

    log_patterns = _compile_log_patterns(cfg)
    exts = _output_exts(cfg)

    rows = []
    seen = set()  # (prog, stem) dedup

    def _add(prog, st, raw):
        if side == "valid":
            st = _normalize_output_stem(st)
        key = (prog.lower(), st.lower())
        if key not in seen:
            seen.add(key)
            rows.append({prog_col: prog, out_col: raw, "output_stem": st})

    # ---- Strategy 1: LOG scanning ----
    if df_logs is not None and not df_logs.empty:
        for _, r in df_logs.iterrows():
            prog = r["program_name"]
            log_path = Path(r["file_path"])
            for st, raw in _extract_stems_from_log(log_path, log_patterns, exts):
                _add(prog, st, raw)

    # ---- Strategy 2: SAS source scanning ----
    # Run for every program regardless of whether log was present
    # This gives many more output-to-program links
    if sas_files is not None and not sas_files.empty:
        for _, r in sas_files.iterrows():
            prog = r["program_name"]
            sas_path = Path(r["file_path"])
            for st, raw in _extract_stems_from_sas(sas_path, exts):
                _add(prog, st, raw)

    # ---- Strategy 3: Disk prefix fallback ----
    # For any disk output files that still have no program linked,
    # try prefix matching against known SAS programs.
    if disk_outputs is not None and not disk_outputs.empty:
        # Build set of stems already covered by strategies 1+2
        covered_stems = {r["output_stem"].lower() for r in rows}

        # Build list of programs to match against
        prog_list = []
        if sas_files is not None and not sas_files.empty:
            prog_list = sas_files["program_name"].tolist()
        elif df_logs is not None and not df_logs.empty:
            prog_list = df_logs["program_name"].tolist()

        for _, r in disk_outputs.iterrows():
            fname = r.get("filename", r.get("program_name", ""))
            st = _stem(fname)
            if not _is_valid_output_stem(st, exts):
                continue
            norm_st = _normalize_output_stem(st) if side == "valid" else st
            if norm_st.lower() in covered_stems:
                continue
            matched = _disk_match_output_to_prog(norm_st, prog_list)
            if matched:
                _add(matched, norm_st, fname)

    if not rows:
        return empty

    df = pd.DataFrame(rows)
    return (
        df.sort_values([prog_col, "output_stem"])
        .drop_duplicates([prog_col, "output_stem"])
        .reset_index(drop=True)
    )


def tfl_pairs(
    prod_logs: pd.DataFrame,
    val_logs: pd.DataFrame,
    prod_out: pd.DataFrame,
    val_out: pd.DataFrame,
    cfg,
    prod_sas: pd.DataFrame = None,
    val_sas: pd.DataFrame = None,
) -> pd.DataFrame:
    """
    Build PROD <-> VAL pairing keyed on output_stem.

    Key improvements over previous version:
    - One-to-many: a single program can map to multiple output files
    - All log patterns applied across entire line (not first-match break)
    - SAS source scanning covers every quoted string, ODS statement, macro param
    - Disk fallback only fills gaps not covered by log/source evidence
    - Val output stems normalised by stripping v- prefix before merge

    Columns: [output_stem, prod_program, prod_output, valid_program, valid_output]
    """
    canonical = ["output_stem", "prod_program", "prod_output", "valid_program", "valid_output"]
    empty = pd.DataFrame(columns=canonical)

    prod_map = _build_side_map(
        prod_logs if prod_logs is not None else pd.DataFrame(),
        "prod", cfg,
        disk_outputs=prod_out,
        sas_files=prod_sas,
    )
    valid_map = _build_side_map(
        val_logs if val_logs is not None else pd.DataFrame(),
        "valid", cfg,
        disk_outputs=val_out,
        sas_files=val_sas,
    )

    if not prod_map.empty and not valid_map.empty:
        pairs = prod_map.merge(valid_map, on="output_stem", how="outer")
    elif not prod_map.empty:
        pairs = prod_map.copy()
    elif not valid_map.empty:
        pairs = valid_map.copy()
    else:
        return empty

    for col in canonical:
        if col not in pairs.columns:
            pairs[col] = pd.NA

    # Remove spurious rows where output_stem still has a val prefix
    # (happens when val SAS code references other val programs)
    val_pfx_list = ["v-", "v_"]

    def _is_val_stem(s):
        s_low = str(s).lower()
        return any(s_low.startswith(p) for p in val_pfx_list)

    if not pairs.empty and "output_stem" in pairs.columns:
        pairs = pairs[~pairs["output_stem"].apply(_is_val_stem)].copy()

    return (
        pairs[canonical]
        .sort_values(["output_stem", "prod_program", "valid_program"], na_position="last")
        .drop_duplicates(["output_stem", "prod_program", "valid_program"])
        .reset_index(drop=True)
    )
