from __future__ import annotations
from pathlib import Path
import re
import pandas as pd

# Matches: * Program Author: First Last (userid) *
# group(1) = full name (may be empty), group(2) = userid
_AUTHOR_RE = re.compile(
    r"Program\s+Author\s*:\s*(.*?)\(([^)]+)\)",
    re.IGNORECASE,
)

# Strip angle-bracket wrapping seen in some environments: <<userid>>
_ANGLE_RE = re.compile(r"^<<(.+)>>$")


def _clean_userid(uid: str) -> str:
    uid = uid.strip()
    m = _ANGLE_RE.match(uid)
    return m.group(1).strip() if m else uid


def _safe_head(path: Path, n: int = 60):
    """Yield up to n lines from the start of a file, safely."""
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for i, line in enumerate(f):
                if i >= n:
                    break
                yield line.rstrip("\n")
    except Exception:
        return


def extract_programmers(df_sas: pd.DataFrame, cfg=None) -> pd.DataFrame:
    """
    Extract programmer full name and userid from SAS program headers.

    Confirmed header format:
        Program Author:  First Last (userid)

    Returns DataFrame with columns:
        program_name, full_name, userid, file_path, mtime, domain,
        is_tool_generated, label
    """
    columns = [
        "program_name", "full_name", "userid", "file_path",
        "mtime", "domain", "is_tool_generated", "label",
    ]
    if df_sas is None or df_sas.empty:
        return pd.DataFrame(columns=columns)

    helper_sfx = []
    if cfg is not None:
        helper_sfx = cfg.get("pairing", "helper_suffixes", default=[]) or []

    rows = []
    for _, r in df_sas.iterrows():
        p = Path(r["file_path"])
        full_name = ""
        userid = ""

        for line in _safe_head(p):
            m = _AUTHOR_RE.search(line)
            if m:
                full_name = m.group(1).strip().rstrip(",").strip()
                userid = _clean_userid(m.group(2))
                break

        # Tool-generated heuristic: in tools folder or TFL program with tool suffix
        is_tool = r.get("label") == "tools" or (
            r["domain"] == "TFL"
            and bool(re.search(
                r"(?:-s|_s|_gen|_auto|_tool)(?:_\d+)?$",
                r["program_name"],
                re.IGNORECASE,
            ))
        )

        rows.append(dict(
            program_name=r["program_name"],
            full_name=full_name,
            userid=userid or ("TOOL" if r.get("label") == "tools" else ""),
            file_path=str(p),
            mtime=r["mtime"],
            domain=r["domain"],
            is_tool_generated=is_tool,
            label=r.get("label", ""),
        ))

    out = pd.DataFrame(rows) if rows else pd.DataFrame(columns=columns)
    if out.empty:
        return out

    return (
        out.sort_values("mtime", ascending=False)
        .drop_duplicates(["domain", "program_name", "label"])
        .reset_index(drop=True)
    )
