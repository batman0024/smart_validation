from __future__ import annotations
from pathlib import Path
import pandas as pd


def tnf_check(study, cfg) -> pd.DataFrame:
    """
    Check TNF conversion currency by comparing mtimes of:
      tnf.xlsx  (master spec in docs/)
      tnfconvert.sas  (conversion program in tools/)
      tnfconvert.log  (conversion log in tools/)

    Returns DataFrame columns: [program_name, status, details]
    Status values: MISSING, NOT RUN, OUTDATED, CURRENT
    """
    excel_name = cfg.get("tnf", "excel_name",    default="tnf.xlsx")
    prog_name  = cfg.get("tnf", "program_name",  default="tnfconvert.sas")
    log_name   = cfg.get("tnf", "log_name",      default="tnfconvert.log")

    tnf_excel = study.docs  / excel_name
    tnf_prog  = study.tools / prog_name
    tnf_log   = study.tools / log_name

    def row(status, details):
        return pd.DataFrame([dict(program_name=prog_name, status=status, details=details)])

    if not tnf_excel.exists():
        return row("MISSING", "TNF Excel not found in docs/")
    excel_m = pd.to_datetime(tnf_excel.stat().st_mtime, unit="s", utc=True)

    if not tnf_prog.exists():
        return row("MISSING", "TNF conversion program not found in tools/")
    prog_m = pd.to_datetime(tnf_prog.stat().st_mtime, unit="s", utc=True)

    if not tnf_log.exists():
        return row("NOT RUN", "TNF conversion has not been run (no log found)")
    log_m = pd.to_datetime(tnf_log.stat().st_mtime, unit="s", utc=True)

    if excel_m > log_m:
        return row("OUTDATED", "TNF Excel updated after last conversion run")
    if prog_m > log_m:
        return row("OUTDATED", "TNF program modified after last conversion run")
    return row("CURRENT", "TNF conversion is up-to-date")
