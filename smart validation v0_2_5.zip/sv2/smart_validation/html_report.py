from __future__ import annotations
import json
import re
from datetime import datetime
import pandas as pd


def _safe(val) -> str:
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return ""
    return str(val)


def _df_to_json(df: pd.DataFrame) -> str:
    if df is None or df.empty:
        return "[]"
    safe = df.copy()
    for col in safe.select_dtypes(include=["datetime64[ns, UTC]", "datetime64[ns]"]).columns:
        safe[col] = safe[col].astype(str)
    for col in safe.columns:
        safe[col] = safe[col].fillna("").astype(str)
    return json.dumps(safe.to_dict(orient="records"), ensure_ascii=True)


def build_html(outputs: dict, study) -> str:
    fr   = outputs.get("final_report", pd.DataFrame())
    iss  = outputs.get("all_issues",   pd.DataFrame())
    ps   = outputs.get("paths_summary", pd.DataFrame())
    tnf  = outputs.get("tnf_check",    pd.DataFrame())
    tflp = outputs.get("tfl_pairs",    pd.DataFrame())

    fr_json  = _df_to_json(fr)
    iss_json = _df_to_json(iss)
    ps_json  = _df_to_json(ps)

    total  = len(fr)
    ok_n   = int((fr["overall_status"] == "OK").sum()) if not fr.empty else 0
    crit_n = int(fr["overall_status"].isin(["Critical Log Error", "Comparison Differences"]).sum()) if not fr.empty else 0
    miss_n = int(fr["overall_status"].isin(["Missing Production Program", "Missing Validation Program"]).sum()) if not fr.empty else 0
    tim_n  = int(fr["overall_status"].isin(["Prod Modified After Run", "Val Modified After Run", "Run Order Issue"]).sum()) if not fr.empty else 0
    ind_n  = int((fr["overall_status"] == "Independence Violation").sum()) if not fr.empty else 0
    hlp_n  = int((fr["overall_status"] == "Helper - No Validation Required").sum()) if not fr.empty else 0
    warn_n = int((fr["overall_status"] == "Warnings Found").sum()) if not fr.empty else 0
    cc_n   = int((fr["compare_status"] == "CLEAN").sum())       if not fr.empty and "compare_status" in fr.columns else 0
    cd_n   = int((fr["compare_status"] == "DIFFERENCES").sum()) if not fr.empty and "compare_status" in fr.columns else 0
    cnr_n  = int((fr["compare_status"] == "NOT RUN").sum())     if not fr.empty and "compare_status" in fr.columns else 0

    gen_time = datetime.now().strftime("%d%b%Y %H:%M:%S").upper()
    proj  = _safe(getattr(study, "project_code", ""))
    stud  = _safe(getattr(study, "study_code",   ""))
    sroot = _safe(getattr(study, "study_root",   ""))

    html = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Smart Validation Report</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap');
:root{
  --bg:#0d1117;--surface:#161b22;--surface2:#1c2333;--border:#30363d;
  --text:#e6edf3;--muted:#8b949e;--accent:#58a6ff;
  --ok-text:#3fb950;--ok-bg:#0d1f0d;--ok-border:#238636;
  --red-text:#f85149;--red-bg:#1f0505;--red-border:#da3633;
  --dkred-text:#ff6b6b;--dkred-bg:#1a0000;--dkred-border:#8b1a1a;
  --warn-text:#d29922;--warn-bg:#1f1600;--warn-border:#9e6a03;
  --blue-text:#58a6ff;--blue-bg:#051525;--blue-border:#1158a7;
  --orange-text:#e08000;--orange-bg:#1f0d00;--orange-border:#a04000;
  --teal-text:#3dcfcf;--teal-bg:#0d1f1f;--teal-border:#1a5050;
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:'IBM Plex Sans',sans-serif;font-size:13px;line-height:1.5}
.header{background:var(--surface);border-bottom:1px solid var(--border);padding:14px 24px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:200}
.logo{font-family:'IBM Plex Mono',monospace;font-size:15px;font-weight:600;color:var(--accent)}
.logo span{color:var(--muted);font-weight:400}
.badges{display:flex;gap:8px;flex-wrap:wrap}
.badge-sm{background:var(--surface2);border:1px solid var(--border);border-radius:4px;padding:2px 8px;font-family:'IBM Plex Mono',monospace;font-size:11px;color:var(--muted)}
.badge-sm strong{color:var(--text)}
.gen-time{font-size:10px;color:var(--muted);font-family:'IBM Plex Mono',monospace}
.metrics{display:grid;grid-template-columns:repeat(8,1fr);gap:1px;background:var(--border);border-bottom:1px solid var(--border)}
.metric{background:var(--surface);padding:12px 14px}
.metric-label{font-size:10px;font-weight:500;text-transform:uppercase;letter-spacing:.7px;color:var(--muted);margin-bottom:4px}
.metric-value{font-family:'IBM Plex Mono',monospace;font-size:20px;font-weight:600;line-height:1}
.metric-sub{font-size:10px;color:var(--muted);margin-top:2px}
.cmp-bar{display:flex;align-items:center;gap:20px;padding:8px 24px;background:var(--surface);border-bottom:1px solid var(--border);font-size:11px;flex-wrap:wrap}
.cmp-label{color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.6px}
.cmp-item{display:flex;align-items:center;gap:5px}
.dot{width:8px;height:8px;border-radius:50%}
.tabs{display:flex;background:var(--surface);border-bottom:1px solid var(--border);padding:0 24px;overflow-x:auto}
.tab{padding:11px 18px;font-size:12px;font-weight:500;color:var(--muted);cursor:pointer;border-bottom:2px solid transparent;transition:color .15s,border-color .15s;white-space:nowrap;display:flex;align-items:center;gap:6px}
.tab:hover{color:var(--text)}
.tab.active{color:var(--accent);border-bottom-color:var(--accent)}
.tcnt{background:var(--surface2);border:1px solid var(--border);border-radius:10px;padding:1px 6px;font-size:10px;font-family:'IBM Plex Mono',monospace}
.filter-bar{display:flex;align-items:center;gap:10px;padding:8px 24px;background:var(--bg);border-bottom:1px solid var(--border);flex-wrap:wrap}
.flbl{font-size:11px;color:var(--muted);font-weight:500}
.fbtn{padding:3px 10px;border-radius:14px;border:1px solid var(--border);background:var(--surface);color:var(--muted);font-size:11px;cursor:pointer;font-family:'IBM Plex Sans',sans-serif;transition:all .15s}
.fbtn:hover{border-color:var(--accent);color:var(--accent)}
.fbtn.active{background:var(--accent);border-color:var(--accent);color:#000;font-weight:600}
.fspacer{flex:1}
.search{background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:4px 10px;color:var(--text);font-size:11px;font-family:'IBM Plex Mono',monospace;width:220px;outline:none}
.search:focus{border-color:var(--accent)}
.search::placeholder{color:var(--muted)}
.pane{display:none}.pane.active{display:block}
.tw{overflow-x:auto;padding:0 24px 24px}
.sec-note{padding:10px 24px 0;font-size:11px;color:var(--muted)}
.sec-note strong{color:var(--text)}
table{width:100%;border-collapse:collapse;margin-top:14px}
thead th{background:var(--surface);color:var(--muted);font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.6px;padding:8px 10px;text-align:left;border-bottom:2px solid var(--border);white-space:nowrap;cursor:pointer;user-select:none;position:sticky;top:53px}
thead th:hover{color:var(--text)}
thead th.sa::after{content:" \25B2";font-size:8px}
thead th.sd::after{content:" \25BC";font-size:8px}
tbody tr{border-bottom:1px solid var(--border);border-left:3px solid transparent;transition:background .1s}
tbody tr:hover{background:var(--surface2)}
tbody tr.hidden{display:none}
td{padding:7px 10px;vertical-align:middle;color:var(--text)}
.mono{font-family:'IBM Plex Mono',monospace;font-size:11px}
.muted{color:var(--muted)}
.badge{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:500;white-space:nowrap}
.bdot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
.s-ok    {background:var(--ok-bg);color:var(--ok-text);border:1px solid var(--ok-border)}
.s-red   {background:var(--red-bg);color:var(--red-text);border:1px solid var(--red-border)}
.s-dkred {background:var(--dkred-bg);color:var(--dkred-text);border:1px solid var(--dkred-border)}
.s-warn  {background:var(--warn-bg);color:var(--warn-text);border:1px solid var(--warn-border)}
.s-blue  {background:var(--blue-bg);color:var(--blue-text);border:1px solid var(--blue-border)}
.s-orange{background:var(--orange-bg);color:var(--orange-text);border:1px solid var(--orange-border)}
.s-teal  {background:var(--teal-bg);color:var(--teal-text);border:1px solid var(--teal-border)}
.s-muted {background:var(--surface2);color:var(--muted);border:1px solid var(--border)}
.upair{display:flex;flex-direction:column;gap:1px}
.uname{font-size:11px}
.uid{font-size:10px;color:var(--muted);font-family:'IBM Plex Mono',monospace}
.iv-ok   {color:var(--ok-text);font-family:'IBM Plex Mono',monospace;font-size:11px}
.iv-viol {color:var(--dkred-text);font-family:'IBM Plex Mono',monospace;font-size:11px;font-weight:700}
.iv-na   {color:var(--muted);font-family:'IBM Plex Mono',monospace;font-size:11px}
.cm-clean{color:var(--ok-text);font-family:'IBM Plex Mono',monospace;font-size:11px;font-weight:600}
.cm-diff {color:var(--red-text);font-family:'IBM Plex Mono',monospace;font-size:11px;font-weight:600}
.cm-nr   {color:var(--muted);font-family:'IBM Plex Mono',monospace;font-size:11px}
.cm-na   {color:var(--muted);font-family:'IBM Plex Mono',monospace;font-size:11px}
.ec-err  {color:var(--red-text);font-family:'IBM Plex Mono',monospace;font-size:11px;font-weight:600;cursor:pointer;text-decoration:underline dotted}
.ec-warn {color:var(--warn-text);font-family:'IBM Plex Mono',monospace;font-size:11px;cursor:pointer;text-decoration:underline dotted}
.ec-zero {color:var(--muted);font-family:'IBM Plex Mono',monospace;font-size:11px}
.fy {color:var(--ok-text);font-family:'IBM Plex Mono',monospace;font-size:11px}
.fn {color:var(--red-text);font-family:'IBM Plex Mono',monospace;font-size:11px}
.fna{color:var(--muted);font-family:'IBM Plex Mono',monospace;font-size:11px}
.it-err  {background:var(--red-bg);color:var(--red-text);border:1px solid var(--red-border)}
.it-warn {background:var(--warn-bg);color:var(--warn-text);border:1px solid var(--warn-border)}
.it-mm   {background:var(--dkred-bg);color:var(--dkred-text);border:1px solid var(--dkred-border)}
.it-clean{background:var(--ok-bg);color:var(--ok-text);border:1px solid var(--ok-border)}
.it-diff {background:var(--red-bg);color:var(--red-text);border:1px solid var(--red-border)}
.it-note {background:var(--surface2);color:var(--muted);border:1px solid var(--border)}
.itext{font-size:11px;font-family:'IBM Plex Mono',monospace;max-width:500px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block;cursor:default}
.paths-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;padding:18px 24px}
.pcard{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:14px}
.pcard-hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}
.pcard-type{font-size:12px;font-weight:600}
.pcard-val{font-size:10px;font-family:'IBM Plex Mono',monospace;color:var(--muted);word-break:break-all}
.footer{border-top:1px solid var(--border);padding:10px 24px;display:flex;justify-content:space-between;font-size:10px;color:var(--muted);font-family:'IBM Plex Mono',monospace;flex-wrap:wrap;gap:6px}
/* Row highlight by status */
tr.row-ok   {border-left-color:var(--ok-border)}
tr.row-warn {border-left-color:var(--warn-border);background:rgba(158,106,3,.04)}
tr.row-red  {border-left-color:var(--red-border);background:rgba(218,54,51,.05)}
tr.row-dkred{border-left-color:var(--dkred-border);background:rgba(139,26,26,.07)}
tr.row-blue {border-left-color:var(--blue-border);background:rgba(17,88,167,.05)}
tr.row-orange{border-left-color:var(--orange-border);background:rgba(160,64,0,.05)}
tr.row-teal {border-left-color:var(--teal-border);background:rgba(26,80,80,.04)}
@media(max-width:900px){.metrics{grid-template-columns:repeat(4,1fr)}.paths-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:600px){.metrics{grid-template-columns:repeat(2,1fr)}.paths-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="header">
  <div style="display:flex;align-items:center;gap:14px">
    <div class="logo">smart<span>validator</span></div>
    <div class="badges">
      <div class="badge-sm">Project: <strong>""" + proj + r"""</strong></div>
      <div class="badge-sm">Study: <strong>""" + stud + r"""</strong></div>
      <div class="badge-sm">Root: <strong>""" + sroot + r"""</strong></div>
    </div>
  </div>
  <div class="gen-time">Generated: """ + gen_time + r"""</div>
</div>

<div class="metrics">
  <div class="metric">
    <div class="metric-label">Total</div>
    <div class="metric-value" style="color:var(--accent)">""" + str(total) + r"""</div>
    <div class="metric-sub">Programs / Outputs</div>
  </div>
  <div class="metric">
    <div class="metric-label">OK</div>
    <div class="metric-value" style="color:var(--ok-text)">""" + str(ok_n) + r"""</div>
    <div class="metric-sub">All checks pass</div>
  </div>
  <div class="metric">
    <div class="metric-label">Critical</div>
    <div class="metric-value" style="color:var(--red-text)">""" + str(crit_n) + r"""</div>
    <div class="metric-sub">Errors / Diff</div>
  </div>
  <div class="metric">
    <div class="metric-label">Missing Val</div>
    <div class="metric-value" style="color:var(--red-text)">""" + str(miss_n) + r"""</div>
    <div class="metric-sub">No validation program</div>
  </div>
  <div class="metric">
    <div class="metric-label">Timing</div>
    <div class="metric-value" style="color:var(--warn-text)">""" + str(tim_n) + r"""</div>
    <div class="metric-sub">Modified / order</div>
  </div>
  <div class="metric">
    <div class="metric-label">Independence</div>
    <div class="metric-value" style="color:var(--dkred-text)">""" + str(ind_n) + r"""</div>
    <div class="metric-sub">Same programmer</div>
  </div>
  <div class="metric">
    <div class="metric-label">Warnings</div>
    <div class="metric-value" style="color:var(--blue-text)">""" + str(warn_n) + r"""</div>
    <div class="metric-sub">Log warnings</div>
  </div>
  <div class="metric">
    <div class="metric-label">Helpers</div>
    <div class="metric-value" style="color:var(--teal-text)">""" + str(hlp_n) + r"""</div>
    <div class="metric-sub">No val required</div>
  </div>
</div>

<div class="cmp-bar">
  <span class="cmp-label">PROC Compare:</span>
  <div class="cmp-item"><div class="dot" style="background:var(--ok-text)"></div><span style="color:var(--ok-text);font-weight:600">CLEAN: """ + str(cc_n) + r"""</span></div>
  <div class="cmp-item"><div class="dot" style="background:var(--red-text)"></div><span style="color:var(--red-text);font-weight:600">DIFFERENCES: """ + str(cd_n) + r"""</span></div>
  <div class="cmp-item"><div class="dot" style="background:var(--muted)"></div><span style="color:var(--muted)">NOT RUN: """ + str(cnr_n) + r"""</span></div>
</div>

<div class="tabs">
  <div class="tab active" onclick="switchTab('paths',this)">Paths</div>
  <div class="tab" onclick="switchTab('sdtm',this)">SDTM <span class="tcnt" id="cnt-sdtm">0</span></div>
  <div class="tab" onclick="switchTab('adam',this)">ADaM <span class="tcnt" id="cnt-adam">0</span></div>
  <div class="tab" onclick="switchTab('tfl',this)">TFL <span class="tcnt" id="cnt-tfl">0</span></div>
  <div class="tab" onclick="switchTab('issues',this)">Log Issues <span class="tcnt" id="cnt-issues">0</span></div>
</div>

<div class="filter-bar" id="fbar" style="display:none">
  <span class="flbl">Filter:</span>
  <button class="fbtn active" onclick="setFilter('ALL',this)">All</button>
  <button class="fbtn" onclick="setFilter('OK',this)">OK</button>
  <button class="fbtn" onclick="setFilter('CRIT',this)">Critical</button>
  <button class="fbtn" onclick="setFilter('TIMING',this)">Timing</button>
  <button class="fbtn" onclick="setFilter('MISSING',this)">Missing</button>
  <button class="fbtn" onclick="setFilter('INDEP',this)">Independence</button>
  <button class="fbtn" onclick="setFilter('COMPARE',this)">Compare Diff</button>
  <div class="fspacer"></div>
  <input class="search" id="fsearch" placeholder="Search..." oninput="applyFilters()">
</div>

<div class="pane active" id="pane-paths"><div id="paths-content"></div></div>
<div class="pane" id="pane-sdtm">
  <div class="sec-note">Domain: <strong>SDTM</strong> &mdash; Pairing by normalized stem (v- prefix stripped). Helper programs excluded from validation requirement.</div>
  <div class="tw"><table id="tbl-sdtm"><thead></thead><tbody></tbody></table></div>
</div>
<div class="pane" id="pane-adam">
  <div class="sec-note">Domain: <strong>ADaM</strong> &mdash; Pairing by normalized stem (v- prefix stripped). _merge / _fmt programs classified as Helper.</div>
  <div class="tw"><table id="tbl-adam"><thead></thead><tbody></tbody></table></div>
</div>
<div class="pane" id="pane-tfl">
  <div class="sec-note">Domain: <strong>TFL</strong> &mdash; One row per output file. Pairing via log footnotes / ODS NOTE / .sas source / disk prefix match.</div>
  <div class="tw"><table id="tbl-tfl"><thead></thead><tbody></tbody></table></div>
</div>
<div class="pane" id="pane-issues">
  <div class="sec-note">All log and LST issues. Click error/warning counts in SDTM/ADaM/TFL tabs to jump here filtered by program.</div>
  <div class="tw"><table id="tbl-issues"><thead></thead><tbody></tbody></table></div>
</div>

<div class="footer">
  <span>smart_validation v0.2.0 | """ + proj + " / " + stud + r"""</span>
  <span>""" + sroot + r""" | """ + gen_time + r"""</span>
</div>

<script>
var FINAL  = """ + fr_json  + r""";
var ISSUES = """ + iss_json + r""";
var PATHS  = """ + ps_json  + r""";

var currentTab = 'paths';
var currentFilter = 'ALL';

// ---- STATUS helpers ----
var STATUS_CLASS = {
  'OK':                              'row-ok',
  'Helper - No Validation Required': 'row-teal',
  'Warnings Found':                  'row-blue',
  'Compare Not Run':                 'row-orange',
  'Val Output Missing':              'row-warn',
  'Prod Modified After Run':         'row-warn',
  'Val Modified After Run':          'row-warn',
  'Run Order Issue':                 'row-warn',
  'Comparison Differences':          'row-red',
  'Critical Log Error':              'row-red',
  'Missing Production Program':      'row-red',
  'Missing Validation Program':      'row-red',
  'Independence Violation':          'row-dkred',
};
var BADGE_CLASS = {
  'OK':                              's-ok',
  'Helper - No Validation Required': 's-teal',
  'Warnings Found':                  's-blue',
  'Compare Not Run':                 's-orange',
  'Val Output Missing':              's-warn',
  'Prod Modified After Run':         's-warn',
  'Val Modified After Run':          's-warn',
  'Run Order Issue':                 's-warn',
  'Comparison Differences':          's-red',
  'Critical Log Error':              's-red',
  'Missing Production Program':      's-red',
  'Missing Validation Program':      's-red',
  'Independence Violation':          's-dkred',
};
var DOT_COLOR = {
  'OK':'var(--ok-text)','Helper - No Validation Required':'var(--teal-text)',
  'Warnings Found':'var(--blue-text)','Compare Not Run':'var(--orange-text)',
  'Val Output Missing':'var(--warn-text)','Prod Modified After Run':'var(--warn-text)',
  'Val Modified After Run':'var(--warn-text)','Run Order Issue':'var(--warn-text)',
  'Comparison Differences':'var(--red-text)','Critical Log Error':'var(--red-text)',
  'Missing Production Program':'var(--red-text)','Missing Validation Program':'var(--red-text)',
  'Independence Violation':'var(--dkred-text)',
};

function e(t,c,h){ var el=document.createElement(t); if(c)el.className=c; if(h!==undefined)el.innerHTML=h; return el; }

function badge(status){
  var bc = BADGE_CLASS[status] || 's-muted';
  var dc = DOT_COLOR[status] || 'var(--muted)';
  return '<span class="badge '+bc+'"><span class="bdot" style="background:'+dc+'"></span>'+esc(status)+'</span>';
}
function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function mono(s,cls){ return '<span class="mono '+(cls||'')+'">'+(s?esc(s):'<span class="muted">--</span>')+'</span>'; }
function userPair(name,uid){
  if(!name&&!uid) return '<span class="muted fna">--</span>';
  return '<div class="upair"><div class="uname">'+esc(name||'')+'</div><div class="uid">'+esc(uid||'')+'</div></div>';
}
function indepBadge(v){
  if(v==='OK')   return '<span class="iv-ok">OK</span>';
  if(v==='VIOLATION') return '<span class="iv-viol">VIOLATION</span>';
  return '<span class="iv-na">'+esc(v||'N/A')+'</span>';
}
function cmpBadge(v){
  if(v==='CLEAN')       return '<span class="cm-clean">CLEAN</span>';
  if(v==='DIFFERENCES') return '<span class="cm-diff">DIFF</span>';
  if(v==='NOT RUN')     return '<span class="cm-nr">NOT RUN</span>';
  return '<span class="cm-na">'+(v||'N/A')+'</span>';
}
function errCell(n,prog,dom){
  n=parseInt(n)||0;
  if(n===0) return '<span class="ec-zero">0</span>';
  return '<span class="ec-err" onclick="jumpIssues(\''+esc(prog)+'\',\''+esc(dom)+'\')">'+n+'</span>';
}
function warnCell(n,prog,dom){
  n=parseInt(n)||0;
  if(n===0) return '<span class="ec-zero">0</span>';
  return '<span class="ec-warn" onclick="jumpIssues(\''+esc(prog)+'\',\''+esc(dom)+'\')">'+n+'</span>';
}
function yn(v){ return v==='YES'?'<span class="fy">YES</span>':'<span class="fn">NO</span>'; }

// ---- MAIN REPORT COLUMNS ----
var SD_AD_COLS = [
  {k:'program_name',    h:'Program'},
  {k:'prod_program',    h:'Prod .sas'},
  {k:'val_program',     h:'Val .sas'},
  {k:'_prod_user',      h:'Prod Programmer'},
  {k:'_val_user',       h:'Val Programmer'},
  {k:'independence',    h:'Independence'},
  {k:'prod_modify_time',h:'Prod Modified'},
  {k:'valid_modify_time',h:'Val Modified'},
  {k:'prod_run_time',   h:'Prod Run'},
  {k:'valid_run_time',  h:'Val Run'},
  {k:'error_count',     h:'Err'},
  {k:'warning_count',   h:'Warn'},
  {k:'compare_status',  h:'Compare'},
  {k:'overall_status',  h:'Overall Status'},
];
var TFL_COLS = [
  {k:'program_name',     h:'Output'},
  {k:'prod_program',     h:'Prod Program'},
  {k:'val_program',      h:'Val Program'},
  {k:'_prod_user',       h:'Prod Programmer'},
  {k:'_val_user',        h:'Val Programmer'},
  {k:'independence',     h:'Independence'},
  {k:'prod_run_time',    h:'Prod Run'},
  {k:'valid_run_time',   h:'Val Run'},
  {k:'prod_output_exists',h:'Prod File'},
  {k:'val_output_exists', h:'Val File'},
  {k:'error_count',      h:'Err'},
  {k:'warning_count',    h:'Warn'},
  {k:'compare_status',   h:'Compare'},
  {k:'overall_status',   h:'Overall Status'},
];
var ISS_COLS = [
  {k:'domain',       h:'Domain'},
  {k:'program_name', h:'Program'},
  {k:'source',       h:'Source'},
  {k:'issue_type',   h:'Type'},
  {k:'issue_text',   h:'Issue Text'},
  {k:'file_path',    h:'File'},
];

function renderCell(col, row, dom){
  var k=col.k, v=row[k]||'';
  if(k==='_prod_user')   return userPair(row['full_name_prod']||'', row['userid_prod']||'');
  if(k==='_val_user')    return userPair(row['full_name_valid']||'', row['userid_valid']||'');
  if(k==='independence') return indepBadge(v);
  if(k==='compare_status') return cmpBadge(v);
  if(k==='overall_status') return badge(v);
  if(k==='error_count')   return errCell(v, row['program_name']||'', dom);
  if(k==='warning_count') return warnCell(v, row['program_name']||'', dom);
  if(k==='prod_output_exists'||k==='val_output_exists') return yn(v);
  if(k==='issue_type'){
    var cls='it-note';
    if(v==='ERROR')         cls='it-err';
    else if(v==='WARNING')  cls='it-warn';
    else if(v==='MISMATCH') cls='it-mm';
    else if(v==='COMPARE_CLEAN') cls='it-clean';
    else if(v==='COMPARE_DIFF')  cls='it-diff';
    return '<span class="badge '+cls+'">'+esc(v)+'</span>';
  }
  if(k==='issue_text') return '<span class="itext" title="'+esc(v)+'">'+esc(v)+'</span>';
  if(k==='source'){
    var sc='s-muted';
    if(v==='PROD_LOG') sc='s-orange'; else if(v==='VAL_LOG') sc='s-blue'; else if(v==='VAL_LST') sc='s-teal';
    return '<span class="badge '+sc+'">'+esc(v)+'</span>';
  }
  if(!v) return '<span class="muted">--</span>';
  var cls2='muted';
  if(k==='program_name'||k==='prod_program'||k==='val_program') cls2='';
  return mono(v,cls2);
}

function buildTable(tblId, cols, data, dom){
  var tbl=document.getElementById(tblId);
  var thead=tbl.querySelector('thead');
  var tbody=tbl.querySelector('tbody');
  thead.innerHTML=''; tbody.innerHTML='';
  var tr=document.createElement('tr');
  cols.forEach(function(col,i){
    var th=document.createElement('th');
    th.textContent=col.h;
    th.setAttribute('data-col',i);
    th.onclick=function(){ sortTable(tblId,i,cols,data,dom); };
    tr.appendChild(th);
  });
  thead.appendChild(tr);
  data.forEach(function(row){
    var tr2=document.createElement('tr');
    var st=row['overall_status']||row['issue_type']||'';
    tr2.className=STATUS_CLASS[st]||'';
    tr2.setAttribute('data-status',st);
    tr2.setAttribute('data-prog',row['program_name']||'');
    tr2.setAttribute('data-dom',row['domain']||'');
    cols.forEach(function(col){
      var td=document.createElement('td');
      td.innerHTML=renderCell(col,row,dom);
      tr2.appendChild(td);
    });
    tbody.appendChild(tr2);
  });
}

function initCounts(){
  var sdtm=FINAL.filter(function(r){return r.domain==='SDTM';}).length;
  var adam=FINAL.filter(function(r){return r.domain==='ADAM';}).length;
  var tfl= FINAL.filter(function(r){return r.domain==='TFL';}).length;
  document.getElementById('cnt-sdtm').textContent=sdtm;
  document.getElementById('cnt-adam').textContent=adam;
  document.getElementById('cnt-tfl').textContent=tfl;
  document.getElementById('cnt-issues').textContent=ISSUES.length;
}

function buildPathsPane(){
  var STATUS_PATH_BADGE={
    'ACTIVE':'s-ok','CURRENT':'s-ok','MISSING':'s-red','EMPTY':'s-warn','OUTDATED':'s-warn','NOT RUN':'s-warn'
  };
  var grid=document.createElement('div'); grid.className='paths-grid';
  PATHS.forEach(function(p){
    var card=document.createElement('div'); card.className='pcard';
    var bc=STATUS_PATH_BADGE[p.status]||'s-muted';
    card.innerHTML='<div class="pcard-hdr"><span class="pcard-type">'+esc(p.path_type)+'</span>'
      +'<span class="badge '+bc+'">'+esc(p.status)+'</span></div>'
      +'<div class="pcard-val">'+esc(p.path_value)+'</div>';
    grid.appendChild(card);
  });
  document.getElementById('paths-content').appendChild(grid);
}

function switchTab(name,el){
  document.querySelectorAll('.pane').forEach(function(p){p.classList.remove('active');});
  document.querySelectorAll('.tab').forEach(function(t){t.classList.remove('active');});
  document.getElementById('pane-'+name).classList.add('active');
  if(el) el.classList.add('active');
  currentTab=name;
  document.getElementById('fbar').style.display=(name==='paths')?'none':'flex';
  currentFilter='ALL';
  document.getElementById('fsearch').value='';
  document.querySelectorAll('.fbtn').forEach(function(b){b.classList.remove('active');});
  document.querySelectorAll('.fbtn')[0].classList.add('active');
  applyFilters();
}

function setFilter(f,btn){
  currentFilter=f;
  document.querySelectorAll('.fbtn').forEach(function(b){b.classList.remove('active');});
  if(btn) btn.classList.add('active');
  applyFilters();
}

function applyFilters(){
  var search=(document.getElementById('fsearch').value||'').toLowerCase();
  var tblId='tbl-'+currentTab;
  var tbl=document.getElementById(tblId);
  if(!tbl) return;
  tbl.querySelectorAll('tbody tr').forEach(function(row){
    var st=row.getAttribute('data-status')||'';
    var prog=row.getAttribute('data-prog')||'';
    var text=row.textContent.toLowerCase();
    var sm=false;
    if(currentFilter==='ALL')  sm=true;
    else if(currentFilter==='OK')    sm=(st==='OK');
    else if(currentFilter==='CRIT')  sm=(st==='Critical Log Error'||st==='Comparison Differences');
    else if(currentFilter==='TIMING') sm=(st.indexOf('Modified')>=0||st==='Run Order Issue');
    else if(currentFilter==='MISSING') sm=(st.indexOf('Missing')>=0);
    else if(currentFilter==='INDEP') sm=(st==='Independence Violation');
    else if(currentFilter==='COMPARE') sm=(st==='Comparison Differences');
    else sm=(st===currentFilter);
    var srm=!search||text.indexOf(search)>=0;
    row.classList.toggle('hidden',!(sm&&srm));
  });
}

function jumpIssues(prog,dom){
  document.getElementById('fsearch').value=prog;
  switchTab('issues', document.querySelectorAll('.tab')[4]);
  currentFilter='ALL';
  applyFilters();
}

function sortTable(tblId,colIdx,cols,data,dom){
  var th=document.getElementById(tblId).querySelectorAll('thead th')[colIdx];
  var asc=!th.classList.contains('sa');
  document.getElementById(tblId).querySelectorAll('thead th').forEach(function(t){t.classList.remove('sa','sd');});
  th.classList.add(asc?'sa':'sd');
  var sorted=data.slice().sort(function(a,b){
    var ak=cols[colIdx].k, av=String(a[ak]||''), bv=String(b[ak]||'');
    return asc?av.localeCompare(bv):bv.localeCompare(av);
  });
  buildTable(tblId,cols,sorted,dom);
}

// Init
window.onload=function(){
  initCounts();
  buildPathsPane();
  buildTable('tbl-sdtm', SD_AD_COLS, FINAL.filter(function(r){return r.domain==='SDTM';}), 'SDTM');
  buildTable('tbl-adam', SD_AD_COLS, FINAL.filter(function(r){return r.domain==='ADAM';}), 'ADAM');
  buildTable('tbl-tfl',  TFL_COLS,   FINAL.filter(function(r){return r.domain==='TFL';}),  'TFL');
  buildTable('tbl-issues', ISS_COLS, ISSUES, 'ALL');
};
</script>
</body>
</html>"""
    return html
