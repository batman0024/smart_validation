"""Smart Validation Tool for SDTM/ADaM/TFL pre-delivery QC."""
__version__ = "0.2.5"
__all__ = []
