"""
TNF Coverage Check
==================
Reads the TNF (Table/Figure/Listing) Excel file from the docs folder,
extracts the TitleKey column from the TFL sheet, and cross-references
those expected output names against the actual output files found in
the production TFL folder.

Reports:
  PRESENT  - TitleKey has at least one matching prod output
  MISSING  - TitleKey has no matching prod output (not yet produced)
  EXTRA    - Prod output exists but has no corresponding TitleKey in TNF
"""
from __future__ import annotations
from pathlib import Path
import re
import pandas as pd


# ---------------------------------------------------------------------------
# TNF file detection
# ---------------------------------------------------------------------------

def find_tnf_file(docs_path: Path, cfg=None) -> Path | None:
    """
    Auto-detect the TNF Excel file in docs/.
    Strategy:
      1. Any .xlsx/.xls with 'tnf' in the filename (case insensitive)
      2. Fall back to config-specified excel_name if set
    Returns the Path if found, else None.
    """
    if not docs_path.exists():
        return None

    # Search by filename pattern
    candidates = [
        f for f in docs_path.iterdir()
        if f.suffix.lower() in (".xlsx", ".xls")
        and "tnf" in f.name.lower()
    ]
    if candidates:
        # prefer most recently modified
        return sorted(candidates, key=lambda f: f.stat().st_mtime, reverse=True)[0]

    # Fall back to config-specified name
    if cfg is not None:
        cfg_name = cfg.get("tnf", "excel_name", default="tnf.xlsx")
        cfg_path = docs_path / str(cfg_name)
        if cfg_path.exists():
            return cfg_path

    return None


# ---------------------------------------------------------------------------
# TNF Excel reading
# ---------------------------------------------------------------------------

def _find_tfl_sheet(wb) -> str | None:
    """Find the TFL sheet by name or by header content."""
    for name in wb.sheetnames:
        if re.search(r"\btfl\b", name, re.IGNORECASE):
            return name
    # Fallback: find sheet whose first row contains TitleKey / TFLT / TFLN
    for name in wb.sheetnames:
        ws = wb[name]
        first_row = [str(c.value or "").lower() for c in
                     next(ws.iter_rows(min_row=1, max_row=1))]
        if any(h in first_row for h in ("titlekey", "tflt", "tfln")):
            return name
    return None


def _col_idx(headers: list, *names) -> int | None:
    """Find first matching column index from a list of candidate names."""
    for name in names:
        try:
            return headers.index(name.lower())
        except ValueError:
            pass
    return None


def read_tnf_tfl(tnf_path: Path) -> pd.DataFrame:
    """
    Read the TFL sheet from the TNF Excel file.

    Returns DataFrame with columns:
        titlekey  - output name stem (e.g. t-pkconc-14c-ams)
        tflt      - type (Table / Listing / Graph / Figure)
        tfln      - TFL number (e.g. 15.10.1.1.1.2)
        title1    - full output description
    """
    try:
        import openpyxl
    except ImportError:
        return pd.DataFrame(columns=["titlekey", "tflt", "tfln", "title1"])

    empty = pd.DataFrame(columns=["titlekey", "tflt", "tfln", "title1"])

    try:
        wb = openpyxl.load_workbook(str(tnf_path), read_only=True, data_only=True)
    except Exception:
        return empty

    sheet_name = _find_tfl_sheet(wb)
    if sheet_name is None:
        wb.close()
        return empty

    ws = wb[sheet_name]
    rows = [tuple(c.value for c in row) for row in ws.iter_rows()]
    wb.close()

    if not rows:
        return empty

    # Locate header row (first row with known column names)
    header_idx = 0
    for i, row in enumerate(rows[:10]):  # search first 10 rows
        row_strs = [str(v or "").lower().strip() for v in row]
        if any(h in row_strs for h in ("titlekey", "tflt", "tfln")):
            header_idx = i
            break

    headers = [str(v or "").lower().strip() for v in rows[header_idx]]

    # Map column positions
    i_tk    = _col_idx(headers, "titlekey") or 0
    i_tflt  = _col_idx(headers, "tflt")
    i_tfln  = _col_idx(headers, "tfln")
    i_title = _col_idx(headers, "title1", "title")

    data = []
    for row in rows[header_idx + 1:]:
        if not any(v for v in row if v is not None):
            continue
        def _get(idx):
            if idx is None or idx >= len(row):
                return ""
            return str(row[idx] or "").strip()

        tk = _get(i_tk)
        if not tk or tk.lower() in ("titlekey", "nan", "none"):
            continue
        data.append({
            "titlekey": tk,
            "tflt":     _get(i_tflt),
            "tfln":     _get(i_tfln),
            "title1":   _get(i_title),
        })

    return pd.DataFrame(data) if data else empty


# ---------------------------------------------------------------------------
# Matching logic
# ---------------------------------------------------------------------------

def _matches(output_stem: str, titlekey: str) -> bool:
    """
    Return True if output_stem corresponds to titlekey.
    Handles:
      - Exact match:   t-s-demog == t-s-demog
      - Prefix match:  t-pkconc-14c-ams-ind1 starts with t-pkconc-14c-ams-
    """
    s = output_stem.lower()
    tk = titlekey.lower()
    return s == tk or s.startswith(tk + "-") or s.startswith(tk + "_")


# ---------------------------------------------------------------------------
# Main cross-reference function
# ---------------------------------------------------------------------------

def tnf_coverage_check(
    study,
    cfg,
    prod_output_stems: list,
) -> pd.DataFrame:
    """
    Cross-reference TNF TitleKeys against actual prod TFL output stems.

    Parameters
    ----------
    study            : StudyPaths object with .docs path
    cfg              : Config object
    prod_output_stems: list of output stems found in prod TFL folder
                       (e.g. ['g-pkconc-14c-ams-ind1', 't-ae-summary-saf', ...])

    Returns
    -------
    DataFrame with columns:
        titlekey     - from TNF
        tflt         - output type (Table/Listing/Graph/Figure)
        tfln         - TFL number
        title1       - output description
        status       - PRESENT / MISSING
        matched_outputs  - comma-separated list of matched prod output stems
        tnf_file     - which TNF file was used
    """
    empty = pd.DataFrame(columns=[
        "titlekey", "tflt", "tfln", "title1",
        "status", "matched_outputs", "tnf_file",
    ])

    tnf_path = find_tnf_file(study.docs, cfg)
    if tnf_path is None:
        return empty

    tnf_df = read_tnf_tfl(tnf_path)
    if tnf_df.empty:
        return empty

    stems_lower = [s.lower() for s in prod_output_stems]
    tnf_name = tnf_path.name

    rows = []
    for _, r in tnf_df.iterrows():
        tk = str(r["titlekey"]).strip()
        if not tk:
            continue
        matched = [s for s in prod_output_stems if _matches(s, tk)]
        rows.append({
            "titlekey":        tk,
            "tflt":            str(r.get("tflt", "")),
            "tfln":            str(r.get("tfln", "")),
            "title1":          str(r.get("title1", ""))[:200],
            "status":          "PRESENT" if matched else "MISSING",
            "matched_outputs": ", ".join(sorted(matched)),
            "tnf_file":        tnf_name,
        })

    return pd.DataFrame(rows) if rows else empty


def tnf_extra_outputs(
    tnf_df: pd.DataFrame,
    prod_output_stems: list,
) -> list:
    """
    Find prod output stems that have no matching TitleKey in the TNF.
    These are EXTRA outputs not planned in the TNF.
    """
    if tnf_df.empty:
        return []
    titlekeys = tnf_df["titlekey"].dropna().tolist()
    extra = []
    for stem in prod_output_stems:
        in_tnf = any(_matches(stem, tk) for tk in titlekeys)
        if not in_tnf:
            extra.append(stem)
    return extra
