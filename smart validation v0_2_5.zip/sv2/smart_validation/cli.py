"""
Smart Validation CLI
Usage examples:
  smartvalidator scan --study /path/to/s4095590
  smartvalidator scan --study /path/to/s4095590 --export
  smartvalidator scan --study /path/to/s4095590 --domain adam
  smartvalidator scan                              # auto-detect from cwd
  smartvalidator summary --study /path/to/s4095590
  smartvalidator check-tnf --study /path/to/s4095590
"""
from __future__ import annotations
import sys
import os
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box
import pandas as pd

app = typer.Typer(
    name="smartvalidator",
    help="Smart Validation Tool - SDTM/ADaM/TFL pre-delivery QC",
    add_completion=False,
)
console = Console()

_STATUS_STYLES = {
    "OK":                              "bold green",
    "Helper - No Validation Required": "cyan",
    "Warnings Found":                  "blue",
    "Compare Not Run":                 "yellow",
    "Val Output Missing":              "yellow",
    "Prod Modified After Run":         "yellow",
    "Val Modified After Run":          "yellow",
    "Run Order Issue":                 "yellow",
    "Comparison Differences":          "bold red",
    "Critical Log Error":              "bold red",
    "Missing Production Program":      "bold red",
    "Missing Validation Program":      "bold red",
    "Independence Violation":          "bold red on dark_red",
    "ACTIVE":  "green",
    "CURRENT": "green",
    "MISSING": "bold red",
    "EMPTY":   "yellow",
    "OUTDATED":"yellow",
    "NOT RUN": "yellow",
    "CLEAN":   "green",
    "DIFFERENCES": "bold red",
}

_COMPARE_STYLES = {
    "CLEAN":       "green",
    "DIFFERENCES": "bold red",
    "NOT RUN":     "dim",
    "N/A":         "dim",
}


def _load(study_root: Path, config_path: str):
    """Load config and build study paths."""
    pkg_dir = Path(__file__).parent.parent
    default_cfg = pkg_dir / "config.yaml"

    cfg_path = Path(config_path) if config_path else None
    if cfg_path is None or not cfg_path.exists():
        cfg_path = study_root / "config.yaml"
    if cfg_path is None or not cfg_path.exists():
        cfg_path = default_cfg
    if not cfg_path.exists():
        cfg_path = None

    from smart_validation.config import Config
    from smart_validation.paths import build_study_paths
    cfg = Config.from_file(str(cfg_path)) if cfg_path and cfg_path.exists() else Config.default()
    study = build_study_paths(cfg, study_root)
    return cfg, study


def _run_scan(study_root: Path, config_path: str):
    from smart_validation.assemble import collect, assemble
    cfg, study = _load(study_root, config_path)
    with console.status("[bold cyan]Scanning study folders...[/]"):
        parts = collect(study, cfg)
    with console.status("[bold cyan]Analyzing logs, pairing programs...[/]"):
        outputs = assemble(parts, study, cfg)
    return cfg, study, outputs


def _print_summary(outputs: dict, study):
    fr = outputs["final_report"]
    if fr is None or fr.empty:
        console.print("[yellow]No programs found.[/]")
        return

    total  = len(fr)
    ok_n   = int((fr["overall_status"] == "OK").sum())
    crit_n = int(fr["overall_status"].isin(["Critical Log Error", "Comparison Differences"]).sum())
    miss_n = int(fr["overall_status"].isin(["Missing Production Program", "Missing Validation Program"]).sum())
    tim_n  = int(fr["overall_status"].isin(["Prod Modified After Run", "Val Modified After Run", "Run Order Issue"]).sum())
    ind_n  = int((fr["overall_status"] == "Independence Violation").sum())
    warn_n = int((fr["overall_status"] == "Warnings Found").sum())
    hlp_n  = int((fr["overall_status"] == "Helper - No Validation Required").sum())
    cc_n   = int((fr["compare_status"] == "CLEAN").sum())       if "compare_status" in fr.columns else 0
    cd_n   = int((fr["compare_status"] == "DIFFERENCES").sum()) if "compare_status" in fr.columns else 0
    cnr_n  = int((fr["compare_status"] == "NOT RUN").sum())     if "compare_status" in fr.columns else 0

    txt = Text()
    txt.append("  Total: ", style="bold"); txt.append("{:>4}".format(total), style="bold cyan"); txt.append("   ")
    txt.append("OK: ", style="bold"); txt.append("{:>4}".format(ok_n), style="bold green"); txt.append("   ")
    txt.append("Critical: ", style="bold"); txt.append("{:>4}".format(crit_n), style="bold red"); txt.append("   ")
    txt.append("Missing Val: ", style="bold"); txt.append("{:>4}".format(miss_n), style="bold red"); txt.append("   ")
    txt.append("Timing: ", style="bold"); txt.append("{:>4}".format(tim_n), style="yellow"); txt.append("   ")
    txt.append("Independence: ", style="bold"); txt.append("{:>4}".format(ind_n), style="bold red"); txt.append("   ")
    txt.append("Warnings: ", style="bold"); txt.append("{:>4}".format(warn_n), style="blue"); txt.append("   ")
    txt.append("Helpers: ", style="bold"); txt.append("{:>4}".format(hlp_n), style="cyan")

    cmp_txt = Text()
    cmp_txt.append("  PROC Compare  ->  ")
    cmp_txt.append("CLEAN: {}".format(cc_n), style="green"); cmp_txt.append("   ")
    cmp_txt.append("DIFFERENCES: {}".format(cd_n), style="bold red"); cmp_txt.append("   ")
    cmp_txt.append("NOT RUN: {}".format(cnr_n), style="dim")

    console.print(Panel(
        Text.assemble(txt, "\n", cmp_txt),
        title="[bold cyan]Study: {} / {}[/]".format(
            getattr(study, "project_code", ""),
            getattr(study, "study_code", ""),
        ),
        border_style="cyan",
    ))


def _print_report_table(fr: pd.DataFrame, domain: Optional[str] = None):
    if fr is None or fr.empty:
        console.print("[yellow]No data.[/]")
        return

    data = fr.copy()
    if domain:
        data = data[data["domain"].str.upper() == domain.upper()]

    is_tfl = (domain == "TFL") if domain else False

    tbl = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold white on #2F5496",
        border_style="dim",
        expand=True,
        show_lines=False,
    )
    tbl.add_column("Domain",  style="dim", width=5, no_wrap=True)
    tbl.add_column("Program", min_width=14, max_width=30, no_wrap=False)
    tbl.add_column("Prod Prog", min_width=12, max_width=25, no_wrap=True)
    tbl.add_column("Val Prog",  min_width=12, max_width=25, no_wrap=True)
    tbl.add_column("Prod User", min_width=10, no_wrap=True)
    tbl.add_column("Val User",  min_width=10, no_wrap=True)
    tbl.add_column("Indep",     width=7, no_wrap=True)
    tbl.add_column("Compare",   width=10, no_wrap=True)
    tbl.add_column("Err", width=4, justify="right")
    tbl.add_column("Warn", width=5, justify="right")
    tbl.add_column("Overall Status", min_width=22, no_wrap=False)

    for _, row in data.iterrows():
        st = str(row.get("overall_status", ""))
        sty = _STATUS_STYLES.get(st, "")
        indep = str(row.get("independence", ""))
        i_sty = "bold red" if indep == "VIOLATION" else ("green" if indep == "OK" else "dim")
        cmp   = str(row.get("compare_status", ""))
        c_sty = _COMPARE_STYLES.get(cmp, "dim")
        err   = str(row.get("error_count", 0))
        wrn   = str(row.get("warning_count", 0))
        e_sty = "bold red" if err != "0" else "dim"
        w_sty = "yellow"   if wrn != "0" else "dim"

        prod_prog = str(row.get("prod_program", ""))
        val_prog  = str(row.get("val_program",  ""))
        # shorten to basename
        prod_prog = Path(prod_prog).name if prod_prog else "--"
        val_prog  = Path(val_prog).name  if val_prog  else "--"

        tbl.add_row(
            str(row.get("domain", "")),
            str(row.get("program_name", "")),
            prod_prog,
            val_prog,
            str(row.get("userid_prod",  "") or "--"),
            str(row.get("userid_valid", "") or "--"),
            Text(indep, style=i_sty),
            Text(cmp,   style=c_sty),
            Text(err,   style=e_sty),
            Text(wrn,   style=w_sty),
            Text(st,    style=sty),
        )

    console.print(tbl)


def _print_issues_table(issues: pd.DataFrame, domain: Optional[str] = None, program: Optional[str] = None):
    if issues is None or issues.empty:
        console.print("[green]No issues found.[/]")
        return

    data = issues.copy()
    if domain:
        data = data[data["domain"].str.upper() == domain.upper()]
    if program:
        data = data[data["program_name"].str.lower() == program.lower()]
    # Exclude COMPARE_CLEAN from issues table (it is a positive result)
    data = data[data["issue_type"] != "COMPARE_CLEAN"]

    if data.empty:
        console.print("[green]No issues for the given filter.[/]")
        return

    tbl = Table(box=box.SIMPLE_HEAD, show_header=True,
                header_style="bold white on #2F5496",
                border_style="dim", expand=True)
    tbl.add_column("Domain",  width=5)
    tbl.add_column("Program", min_width=14, max_width=25)
    tbl.add_column("Source",  width=10)
    tbl.add_column("Type",    width=13)
    tbl.add_column("Issue Text", min_width=40, max_width=80, no_wrap=False)

    type_styles = {
        "ERROR":         "bold red",
        "WARNING":       "yellow",
        "MISMATCH":      "bold red",
        "COMPARE_DIFF":  "bold red",
        "NOTE":          "dim",
    }
    for _, row in data.iterrows():
        it   = str(row.get("issue_type", ""))
        sty  = type_styles.get(it, "")
        tbl.add_row(
            str(row.get("domain", "")),
            str(row.get("program_name", "")),
            str(row.get("source", "")),
            Text(it, style=sty),
            str(row.get("issue_text", ""))[:200],
        )
    console.print(tbl)


# ------------------------------------------------------------------ Commands

@app.command()
def scan(
    study: str  = typer.Option(None, "--study", "-s",
                               help="Path to study root folder. Defaults to current directory."),
    config: str = typer.Option(None, "--config", "-c",
                               help="Path to config.yaml. Auto-detected if omitted."),
    domain: str = typer.Option(None, "--domain", "-d",
                               help="Filter output to one domain: sdtm, adam, tfl."),
    export: bool = typer.Option(False, "--export", "-e", is_flag=True,
                                help="Write Excel + HTML + CSV reports to docs/ folder."),
    issues: bool = typer.Option(False, "--issues", "-i", is_flag=True,
                                help="Also print the log issues table."),
):
    """
    Run a full validation scan and print results to the terminal.

    Examples:
      smartvalidator scan
      smartvalidator scan --study /studies/p001/s001 --export
      smartvalidator scan --domain adam --issues
    """
    study_root = Path(study).resolve() if study else Path.cwd()
    if not study_root.exists():
        console.print("[bold red]ERROR:[/] Study path does not exist: {}".format(study_root))
        raise typer.Exit(1)

    console.print()
    console.print("[bold cyan]Smart Validation Tool[/]  v0.2.0")
    console.print("[dim]Study root:[/] {}".format(study_root))
    console.print()

    cfg, study_obj, outputs = _run_scan(study_root, config)
    _print_summary(outputs, study_obj)

    fr = outputs["final_report"]
    if fr is not None and not fr.empty:
        dom_filter = domain.upper() if domain else None
        _print_report_table(fr, dom_filter)

    if issues:
        console.print("\n[bold]Log Issues:[/]")
        _print_issues_table(outputs["all_issues"], domain)

    if export:
        console.print()
        with console.status("[bold cyan]Writing reports...[/]"):
            from smart_validation.report import write_reports
            written = write_reports(outputs, study_obj, cfg)
        for label, path in written.items():
            console.print("[green]Exported [{}]:[/] {}".format(label, path))

    console.print()


@app.command()
def summary(
    study: str  = typer.Option(None, "--study", "-s"),
    config: str = typer.Option(None, "--config", "-c"),
):
    """
    Print a one-screen readiness summary only (fast, no full table).
    """
    study_root = Path(study).resolve() if study else Path.cwd()
    cfg, study_obj, outputs = _run_scan(study_root, config)
    _print_summary(outputs, study_obj)


@app.command("check-tnf")
def check_tnf(
    study: str  = typer.Option(None, "--study", "-s"),
    config: str = typer.Option(None, "--config", "-c"),
):
    """
    Check TNF conversion currency only.
    """
    study_root = Path(study).resolve() if study else Path.cwd()
    cfg, study_obj = _load(study_root, config)
    from smart_validation.tnf import tnf_check
    result = tnf_check(study_obj, cfg)
    console.print(result.to_string(index=False))


@app.command("show-issues")
def show_issues(
    study:   str = typer.Option(None,  "--study",   "-s"),
    config:  str = typer.Option(None,  "--config",  "-c"),
    domain:  str = typer.Option(None,  "--domain",  "-d"),
    program: str = typer.Option(None,  "--program", "-p"),
):
    """
    Show only log issues table, optionally filtered by domain or program.
    """
    study_root = Path(study).resolve() if study else Path.cwd()
    cfg, study_obj, outputs = _run_scan(study_root, config)
    _print_issues_table(outputs["all_issues"], domain, program)


def main():
    app()


if __name__ == "__main__":
    main()
