# Smart Validation Tool v0.2.0

Pre-delivery QC tool for SDTM / ADaM / TFL clinical programming.
Scans study folders, pairs production vs validation programs, checks
log health, PROC COMPARE results, timing integrity, and independence.

---

## Quick Start

### Install

```
pip install smart_validation-0.2.0-py3-none-any.whl
```

Or directly from source:

```
pip install -e .
```

---

## Usage

### 1. Streamlit Web UI

```
streamlit run app_streamlit.py
```

Open http://localhost:8501 in your browser.
Select study via dropdown or paste a UNC path, then click Run Scan.
Download Excel or HTML report from the UI.

To serve for the whole team on a central server:

```
streamlit run app_streamlit.py --server.port 8501 --server.address 0.0.0.0
```

---

### 2. CLI (MobaXterm / PuTTY / Windows CMD)

Run from inside the study folder:

```
cd /gsasdata/biometrics/projects/p001/s4095590
smartvalidator scan
```

Or specify the path explicitly:

```
smartvalidator scan --study /path/to/s4095590
smartvalidator scan --study /path/to/s4095590 --export
smartvalidator scan --study /path/to/s4095590 --domain adam
smartvalidator scan --study /path/to/s4095590 --issues
```

Other commands:

```
smartvalidator summary   --study /path/to/s4095590
smartvalidator check-tnf --study /path/to/s4095590
smartvalidator show-issues --study /path/to/s4095590 --domain sdtm
smartvalidator show-issues --study /path/to/s4095590 --program adae
```

---

## Outputs

All reports written to the study docs/ folder:

- Validation_Report_YYYYMMDD_HHMMSS.xlsx  (Excel, 6 sheets + Summary)
- Validation_Report_YYYYMMDD_HHMMSS.html  (standalone interactive HTML)
- final_report_YYYYMMDD_HHMMSS.csv
- issues_YYYYMMDD_HHMMSS.csv

---

## Folder Layout Expected

```
study_root/
  sdtmprog/     production SDTM programs (.sas, .log, .lst)
  adamprog/     production ADaM programs (.sas, .log, .lst)
  prog/         production TFL programs  (.sas, .log, .pdf, .rtf)
  validation/   validation programs      (.sas, .log, .lst, .pdf, .rtf)
  tools/        tool-generated programs
  docs/         tnf.xlsx, reports written here
```

All folder names are configurable in config.yaml.

---

## config.yaml

Key settings:

```yaml
studies_root: "\\\\server\\biometrics\\projects"

layout:
  prod_sdtm_dir: "sdtmprog"
  prod_adam_dir: "adamprog"
  prod_tfl_dir:  "prog"
  valid_dir:     "validation"
  tools_dir:     "tools"
  docs_dir:      "docs"

tfl:
  output_exts: [".pdf", ".rtf", ".out", ".xlsx"]

pairing:
  val_prefixes:    ["v-", "v_"]
  helper_suffixes: ["_merge", "_fmt", "_format", "_macro", "_util"]

scan:
  max_log_lines: 10000

timing:
  run_order_tolerance_hours: 0
```

---

## Pairing Logic

### SDTM / ADaM
Paired by normalized program stem.
v-adsl.sas pairs with adsl.sas (v- prefix stripped).
Programs ending in _merge, _fmt, _util are classified as
Helper - No Validation Required and excluded from gap reporting.

### TFL
Paired by output file stem (not program name).
One production program may generate many outputs.
One validation program may validate many outputs.
The output filename is extracted from log files in priority order:
  1. Footnote text:  Output file: name.pdf
  2. ODS NOTE:       NOTE: Writing/closing file: name.pdf
  3. ODS statement:  ods pdf file='name.pdf'
  4. SAS source:     static footnote definition
  5. Disk scan:      .pdf/.rtf files matched by longest stem prefix

---

## Overall Status Priority

1.  Missing Production Program
2.  Missing Validation Program
3.  Independence Violation  (same userid on both sides)
4.  Critical Log Error      (ERROR: in log)
5.  Comparison Differences  (PROC COMPARE found diffs)
6.  Prod Modified After Run
7.  Val Modified After Run
8.  Run Order Issue
9.  Warnings Found
10. Compare Not Run
11. Helper - No Validation Required
12. OK

---

## Program Header Format

The tool reads:

```sas
Program Author:  First Last (userid)
```

Full name and userid are extracted separately.
Independence is checked by comparing userid_prod vs userid_valid.
Angle-bracket wrapping (<<userid>>) is automatically stripped.
