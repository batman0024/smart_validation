from __future__ import annotations
from pathlib import Path
import re
import pandas as pd

AUTHOR_RE = re.compile(r'^\s*Program\s+Author:\s*\(([^)]+)\)\s*$', re.IGNORECASE)

def safe_head(path: Path, n: int = 60):
    lines = []
    try:
        with path.open('r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i >= n:
                    break
                lines.append(line.rstrip('\n'))
    except Exception:
        pass
    return lines

def extract_programmers(df_sas: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, r in df_sas.iterrows():
        p = Path(r['file_path'])
        userid = ''
        for L in safe_head(p):
            m = AUTHOR_RE.match(L.strip())
            if m:
                userid = m.group(1).strip()
                break
        is_tool = (r['domain'] == 'TFL' and ('-s' in r['program_name']))
        rows.append(dict(
            program_name=r['program_name'],
            userid=userid or ('TOOL' if r.get('label') == 'tools' else ''),
            file_path=str(p),
            mtime=r['mtime'],
            domain=r['domain'],
            is_tool_generated=is_tool,
            label=r.get('label', '')
        ))
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    return out.sort_values('mtime', ascending=False).drop_duplicates(['domain','program_name','label'])
