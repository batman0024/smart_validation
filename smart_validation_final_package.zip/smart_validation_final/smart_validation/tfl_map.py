from __future__ import annotations
from pathlib import Path
import re
import pandas as pd

def safe_lines(path: Path, n: int=20000):
    try:
        with path.open('r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i>=n: break
                yield line.rstrip('\n')
    except Exception:
        return

def map_from_logs(df_logs: pd.DataFrame, cfg) -> dict:
    patterns = [re.compile(p) for p in (cfg.get('tfl','log_output_patterns', default=[]) or [])]
    mapping = {}
    for _, r in df_logs.iterrows():
        if r['domain'] != 'TFL':
            continue
        prog = r['program_name']
        p = Path(r['file_path'])
        for L in safe_lines(p):
            for pat in patterns:
                m = pat.search(L)
                if not m:
                    continue
                text = ' '.join(m.groups()) if m.groups() else L
                for c in re.findall(r'([\w\-/\\\.]+\.out)', text, flags=re.IGNORECASE):
                    stem = Path(c).stem
                    if stem:
                        mapping.setdefault(stem, prog)
    for _, r in df_logs.iterrows():
        if r['domain'] == 'TFL':
            mapping.setdefault(r['program_name'], r['program_name'])
    return mapping

def map_from_outfiles(df_out: pd.DataFrame) -> set[str]:
    stems = set()
    for _, r in df_out.iterrows():
        if r['ext'] == '.out':
            stems.add(Path(r['file_path']).stem)
    return stems

def tfl_pairs(prod_logs: pd.DataFrame, val_logs: pd.DataFrame, prod_out: pd.DataFrame, val_out: pd.DataFrame, cfg) -> pd.DataFrame:
    prod_map = map_from_logs(prod_logs, cfg) if not prod_logs.empty else {}
    val_map  = map_from_logs(val_logs, cfg) if not val_logs.empty else {}
    prod_stems = map_from_outfiles(prod_out)
    val_stems  = map_from_outfiles(val_out)
    all_stems = sorted(prod_stems & val_stems)
    rows = []
    for stem in all_stems:
        rows.append(dict(output_stem=stem, prod_program=prod_map.get(stem, ''), valid_program=val_map.get(stem, '')))
    return pd.DataFrame(rows)
