"""
Streamlit web UI for Smart Validation Tool.
Run with:  streamlit run app_streamlit.py
"""
from __future__ import annotations
import sys
import os
from pathlib import Path

pkg_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.abspath(os.path.join(pkg_dir, os.pardir))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

import streamlit as st
import pandas as pd

from smart_validation.config import Config
from smart_validation.paths import build_study_paths, get_full_path_label
from smart_validation.assemble import collect, assemble
from smart_validation.report import write_reports

st.set_page_config(
    page_title="Smart Validation Tool",
    page_icon=":microscope:",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Theme definitions - LIGHT and DARK
# ---------------------------------------------------------------------------
_THEMES = {
    "light": {
        "OK":                              ("#d4edda", "#155724"),
        "Helper - No Validation Required": ("#d1ecf1", "#0c5460"),
        "Warnings Found":                  ("#cce5ff", "#004085"),
        # Compare Not Run = orange (regulatory gap - validation not performed)
        "Compare Not Run":                 ("#ffe0cc", "#7B3F00"),
        "Val Output Missing":              ("#ffe0cc", "#7B3F00"),
        "Prod Modified After Run":         ("#fff3cd", "#856404"),
        "Val Modified After Run":          ("#fff3cd", "#856404"),
        "Run Order Issue":                 ("#fff3cd", "#856404"),
        "Comparison Differences":          ("#f8d7da", "#721c24"),
        "Critical Log Error":              ("#f8d7da", "#721c24"),
        "Missing Production Program":      ("#f8d7da", "#721c24"),
        "Missing Validation Program":      ("#f8d7da", "#721c24"),
        "Independence Violation":          ("#f5c6cb", "#491217"),
        "UNKNOWN":  ("#fff3cd", "#856404"),
        "ACTIVE":   ("#d4edda", "#155724"),
        "CURRENT":  ("#d4edda", "#155724"),
        "MISSING":  ("#f8d7da", "#721c24"),   # single entry - no duplicate
        "EMPTY":    ("#fff3cd", "#856404"),
        "OUTDATED": ("#fff3cd", "#856404"),
        "CLEAN":    ("#d4edda", "#155724"),
        "DIFFERENCES": ("#f8d7da", "#721c24"),
        "NOT RUN":  ("#fff3cd", "#856404"),
        "PRESENT":  ("#d4edda", "#155724"),
        "EXTRA":    ("#fff3cd", "#856404"),
    },
    "dark": {
        "OK":                              ("#0d1f0d", "#3fb950"),
        "Helper - No Validation Required": ("#0d1f1f", "#3dcfcf"),
        "Warnings Found":                  ("#051525", "#58a6ff"),
        # Compare Not Run = orange (regulatory gap - validation not performed)
        "Compare Not Run":                 ("#2a1000", "#e08000"),
        "Val Output Missing":              ("#2a1000", "#e08000"),
        "Prod Modified After Run":         ("#1f1600", "#d29922"),
        "Val Modified After Run":          ("#1f1600", "#d29922"),
        "Run Order Issue":                 ("#1f1600", "#d29922"),
        "Comparison Differences":          ("#1f0505", "#f85149"),
        "Critical Log Error":              ("#1f0505", "#f85149"),
        "Missing Production Program":      ("#1f0505", "#f85149"),
        "Missing Validation Program":      ("#1f0505", "#f85149"),
        "Independence Violation":          ("#1a0000", "#ff6b6b"),
        "UNKNOWN":  ("#1f1600", "#d29922"),
        "ACTIVE":   ("#0d1f0d", "#3fb950"),
        "CURRENT":  ("#0d1f0d", "#3fb950"),
        "MISSING":  ("#1f0505", "#f85149"),   # single entry - no duplicate
        "EMPTY":    ("#1f1600", "#d29922"),
        "OUTDATED": ("#1f1600", "#d29922"),
        "CLEAN":    ("#0d1f0d", "#3fb950"),
        "DIFFERENCES": ("#1f0505", "#f85149"),
        "NOT RUN":  ("#1f1600", "#d29922"),
        "PRESENT":  ("#0d1f0d", "#3fb950"),
        "EXTRA":    ("#1f1600", "#d29922"),
    },
}

# Row highlight colors for full-row styling (bg, text)
# Compare Not Run = distinct orange (not the same as timing amber)
_ROW_COLORS_LIGHT = {
    "Independence Violation":       ("#fde8ea", "#491217"),
    "Critical Log Error":           ("#fde8ea", "#721c24"),
    "Comparison Differences":       ("#fde8ea", "#721c24"),
    "Missing Production Program":   ("#fde8ea", "#721c24"),
    "Missing Validation Program":   ("#fde8ea", "#721c24"),
    "Prod Modified After Run":      ("#fffacd", "#856404"),
    "Val Modified After Run":       ("#fffacd", "#856404"),
    "Run Order Issue":              ("#fffacd", "#856404"),
    "Val Output Missing":           ("#ffe0cc", "#7B3F00"),
    "Compare Not Run":              ("#ffe0cc", "#7B3F00"),   # orange - regulatory gap
    "Warnings Found":               ("#e8f4fd", "#004085"),
    "Helper - No Validation Required": ("#e8f8f8", "#0c5460"),
    "UNKNOWN":                      ("#fffacd", "#856404"),   # amber - independence unknown
    "OK":                           ("", ""),
    "PRESENT":                      ("", ""),
    "MISSING":                      ("#fde8ea", "#721c24"),
    "EXTRA":                        ("#fffacd", "#856404"),
}

_ROW_COLORS_DARK = {
    "Independence Violation":       ("#2a0a0a", "#ff6b6b"),
    "Critical Log Error":           ("#200808", "#f85149"),
    "Comparison Differences":       ("#200808", "#f85149"),
    "Missing Production Program":   ("#200808", "#f85149"),
    "Missing Validation Program":   ("#200808", "#f85149"),
    "Prod Modified After Run":      ("#201500", "#d29922"),
    "Val Modified After Run":       ("#201500", "#d29922"),
    "Run Order Issue":              ("#201500", "#d29922"),
    "Val Output Missing":           ("#2a1000", "#e08000"),
    "Compare Not Run":              ("#2a1000", "#e08000"),   # orange - regulatory gap
    "Warnings Found":               ("#040f1f", "#58a6ff"),
    "Helper - No Validation Required": ("#041515", "#3dcfcf"),
    "UNKNOWN":                      ("#201500", "#d29922"),   # amber - independence unknown
    "OK":                           ("", ""),
    "PRESENT":                      ("", ""),
    "MISSING":                      ("#200808", "#f85149"),
    "EXTRA":                        ("#201500", "#d29922"),
}


def _get_theme():
    return st.session_state.get("theme", "light")


def _style_col(df: pd.DataFrame, col: str):
    """Style only the status column cell."""
    theme = _get_theme()
    color_map = _THEMES[theme]

    def _f(val):
        pair = color_map.get(str(val))
        if pair:
            bg, text = pair
            return "background-color: {}; color: {}; font-weight: 600".format(bg, text)
        return ""

    styler = df.style
    if col in df.columns:
        try:
            if hasattr(styler, "map"):
                styler = styler.map(_f, subset=[col])
            else:
                styler = styler.applymap(_f, subset=[col])
        except Exception:
            pass
    return styler


def _style_full_rows(df: pd.DataFrame, status_col: str):
    """Apply full-row background + text color based on overall_status."""
    theme = _get_theme()
    row_colors = _ROW_COLORS_DARK if theme == "dark" else _ROW_COLORS_LIGHT

    def _row_style(row):
        status = str(row.get(status_col, ""))
        pair = row_colors.get(status, ("", ""))
        bg, text = pair
        if bg:
            return ["background-color: {}; color: {}".format(bg, text)] * len(row)
        return [""] * len(row)

    try:
        return df.style.apply(_row_style, axis=1)
    except Exception:
        return df.style


# Subfolders that indicate a folder is a programming work root
_WORK_DIRS = {"adamprog", "sdtmprog", "prog", "validation", "tools",
              "vdata", "adamdata", "sdtmdata"}


def _is_work_root(path: Path) -> bool:
    """True if this folder directly contains SAS programming subdirectories."""
    if not path.is_dir():
        return False
    try:
        subdirs = {d.name.lower() for d in path.iterdir() if d.is_dir()}
        return bool(subdirs & _WORK_DIRS)
    except Exception:
        return False


def _list_subdirs(path: Path) -> list:
    """List all immediate subdirectories, sorted."""
    if not path.is_dir():
        return []
    try:
        return sorted([d.name for d in path.iterdir() if d.is_dir()])
    except Exception:
        return []


@st.cache_resource
def _load_config(path: str) -> Config:
    return Config.from_file(path)


@st.cache_data(show_spinner=False)
def _list_projects(studies_root: str):
    p = Path(studies_root)
    if not p.exists():
        return []
    return sorted([d.name for d in p.iterdir()
                   if d.is_dir() and d.name.lower().startswith("p")])


@st.cache_data(show_spinner=False)
def _list_studies(studies_root: str, project: str):
    p = Path(studies_root) / project
    if not p.exists():
        return []
    return sorted([d.name for d in p.iterdir()
                   if d.is_dir() and d.name.lower().startswith("s")])


def _pick_folder() -> str:
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.wm_attributes("-topmost", 1)
        folder = filedialog.askdirectory()
        root.destroy()
        return folder or ""
    except Exception:
        return ""


def _fmt_dt(val) -> str:
    try:
        if pd.isna(val):
            return "--"
        return str(val)[:19]
    except Exception:
        return str(val)


def _basename(fp: str) -> str:
    """Return just the filename stem (no path, no extension). Handles UNC and Unix paths."""
    import re as _re
    if not fp or str(fp) in ("", "nan", "--"):
        return "--"
    # Split on both forward and backslash to handle UNC paths on Linux/Windows
    parts = _re.split(r"[/\\]", str(fp))
    filename = next((p for p in reversed(parts) if p), "")
    if not filename:
        return "--"
    dot = filename.rfind(".")
    if dot > 0:
        return filename[:dot]
    return filename


def _shorten_df(df: pd.DataFrame, cols: list) -> pd.DataFrame:
    """Replace full file paths in specified columns with stem/basename only."""
    out = df.copy()
    for col in cols:
        if col in out.columns:
            out[col] = out[col].apply(_basename)
    return out


def main():
    # ---- Theme toggle in top-right ----
    col_title, col_toggle = st.columns([8, 1])
    with col_title:
        st.title(":microscope: Smart Validation Tool")
        st.caption("Pre-delivery QC for SDTM / ADaM / TFL programs")
    with col_toggle:
        st.write("")
        st.write("")
        current_theme = _get_theme()
        label = ":sunny: Light" if current_theme == "dark" else ":crescent_moon: Dark"
        if st.button(label, key="theme_toggle", use_container_width=True):
            st.session_state["theme"] = "light" if current_theme == "dark" else "dark"
            st.rerun()

    # ---- Inject CSS for light/dark page background ----
    theme = _get_theme()
    if theme == "light":
        st.markdown(
            """
            <style>
            [data-testid="stAppViewContainer"] { background-color: #f8f9fa; }
            [data-testid="stSidebar"] { background-color: #ffffff; }
            .stDataFrame { background-color: #ffffff; }
            </style>
            """,
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            """
            <style>
            [data-testid="stAppViewContainer"] { background-color: #0d1117; }
            [data-testid="stSidebar"] { background-color: #161b22; }
            </style>
            """,
            unsafe_allow_html=True,
        )

    # ------------------------------------------------------------------ Sidebar
    with st.sidebar:
        st.header("Study Selection")
        config_path = st.text_input("Config path", value="config.yaml")

        try:
            cfg = _load_config(config_path)
        except Exception:
            cfg = Config.default()

        studies_root = cfg.get("studies_root", default="")
        mode = st.radio("Select study by", ["Dropdown", "Manual path"])

        study_root = None
        if mode == "Dropdown":
            projects = _list_projects(studies_root)
            proj = st.selectbox("Project", options=projects or ["(none)"])
            studies = _list_studies(studies_root, proj) if proj and proj != "(none)" else []
            stud = st.selectbox("Study", options=studies or ["(none)"])

            base = Path(studies_root) / proj / stud if (
                proj and stud and proj != "(none)" and stud != "(none)"
            ) else None

            if base is not None and base.exists():
                if _is_work_root(base):
                    # Study folder itself has adamprog/sdtmprog etc. -> no extra levels
                    study_root = base
                else:
                    # Show Task level (e.g. final, cdm, noncdp)
                    tasks = _list_subdirs(base)
                    task = st.selectbox(
                        "Task folder",
                        options=tasks or ["(none)"],
                        help="e.g. final, cdm, noncdp, stats",
                    )
                    if task and task != "(none)":
                        task_path = base / task
                        if _is_work_root(task_path):
                            # Task folder itself contains adamprog etc. -> no version level
                            study_root = task_path
                        else:
                            # Show Version level (e.g. draft1, version1, version2)
                            versions = _list_subdirs(task_path)
                            ver = st.selectbox(
                                "Version",
                                options=versions or ["(none)"],
                                help="e.g. draft1, version1, version2",
                            )
                            if ver and ver != "(none)":
                                ver_path = task_path / ver
                                study_root = ver_path
        else:
            default = str(studies_root) if studies_root else ""
            if st.button("Browse..."):
                picked = _pick_folder()
                if picked:
                    st.session_state["picked_dir"] = picked
            manual = st.text_input(
                "Study root path",
                value=st.session_state.get("picked_dir", default),
                placeholder="\\\\server\\path\\to\\study",
            )
            if manual:
                study_root = Path(manual)

        st.divider()
        st.subheader("Options")
        show_helpers = st.checkbox("Show helper programs", value=False)
        auto_refresh = st.checkbox("Auto-refresh (30s)", value=False)
        if auto_refresh:
            try:
                import time
                time.sleep(30)
                st.rerun()
            except Exception:
                pass

        st.divider()
        run_btn = st.button(":rocket: Run Scan", type="primary", use_container_width=True)

    # ------------------------------------------------------------------ Main area
    if not study_root:
        st.info(":point_left: Select a study path in the sidebar, then click **Run Scan**.")
        return

    if not Path(study_root).exists():
        st.error("Study path does not exist: `{}`".format(study_root))
        return

    if not run_btn and "sv_outputs" not in st.session_state:
        try:
            _lbl = get_full_path_label(Path(study_root))
        except Exception:
            _lbl = str(study_root)
        st.info("Study: **{}**  |  Path: `{}`  |  Click **Run Scan** to start.".format(_lbl, study_root))
        return

    if run_btn:
        study_paths = build_study_paths(cfg, Path(study_root))
        with st.spinner("Scanning and analyzing..."):
            parts   = collect(study_paths, cfg)
            outputs = assemble(parts, study_paths, cfg)
        st.session_state["sv_outputs"]      = outputs
        st.session_state["sv_study_paths"]  = study_paths
        st.session_state["sv_cfg"]          = cfg

    outputs     = st.session_state.get("sv_outputs", {})
    study_paths = st.session_state.get("sv_study_paths")
    cfg         = st.session_state.get("sv_cfg", Config.default())

    if not outputs:
        return

    fr   = outputs.get("final_report", pd.DataFrame())
    iss  = outputs.get("all_issues",   pd.DataFrame())

    # Filter helpers
    fr_display = fr.copy()
    if not show_helpers and not fr_display.empty and "is_helper" in fr_display.columns:
        fr_display = fr_display[~fr_display["is_helper"].astype(bool)]

    # ---- KPI bar ----
    total  = len(fr_display)
    ok_n   = int((fr_display["overall_status"] == "OK").sum())                                        if not fr_display.empty else 0
    crit_n = int(fr_display["overall_status"].isin(["Critical Log Error","Comparison Differences"]).sum()) if not fr_display.empty else 0
    miss_n = int(fr_display["overall_status"].isin(["Missing Production Program","Missing Validation Program"]).sum()) if not fr_display.empty else 0
    tim_n  = int(fr_display["overall_status"].isin(["Prod Modified After Run","Val Modified After Run","Run Order Issue"]).sum()) if not fr_display.empty else 0
    ind_n  = int((fr_display["overall_status"] == "Independence Violation").sum())                   if not fr_display.empty else 0
    cmp_nr_n = int((fr_display["overall_status"] == "Compare Not Run").sum())                        if not fr_display.empty else 0

    c1, c2, c3, c4, c5, c6, c7, c8 = st.columns(8)
    c1.metric("Total",           total)
    c2.metric("OK",              ok_n)
    c3.metric("Critical / Diff", crit_n)
    c4.metric("Independence",    ind_n,     delta=str(ind_n)  if ind_n  else None, delta_color="inverse")
    c5.metric("Compare Not Run", cmp_nr_n,  delta=str(cmp_nr_n) if cmp_nr_n else None, delta_color="inverse")
    c6.metric("Missing Val",     miss_n)
    c7.metric("Timing Issues",   tim_n)
    if "compare_status" in fr_display.columns and not fr_display.empty:
        cc_n = int((fr_display["compare_status"] == "CLEAN").sum())
        c8.metric("Compare Clean", cc_n)

    st.divider()

    # ---- Tabs ----
    tab_paths, tab_sdtm, tab_adam, tab_tfl, tab_issues, tab_tnf = st.tabs(
        ["Paths", "SDTM", "ADaM", "TFL", "Log Issues", "TNF Coverage"]
    )

    with tab_paths:
        ps = outputs.get("paths_summary", pd.DataFrame())
        if not ps.empty:
            st.dataframe(
                _style_col(ps, "status"),
                use_container_width=True,
                hide_index=True,
            )
        tnf = outputs.get("tnf_check", pd.DataFrame())
        if not tnf.empty:
            st.subheader("TNF Check")
            st.dataframe(_style_col(tnf, "status"), use_container_width=True, hide_index=True)

    def _show_domain(tab, dom):
        with tab:
            sub = fr_display[fr_display["domain"] == dom].copy() if not fr_display.empty else pd.DataFrame()
            if sub.empty:
                st.info("No programs found for domain: {}".format(dom))
                return

            # Format datetime cols
            for dc in ["prod_modify_time", "valid_modify_time", "prod_run_time", "valid_run_time"]:
                if dc in sub.columns:
                    sub[dc] = sub[dc].apply(_fmt_dt)

            # --- Shorten file paths to stem only ---
            path_cols = ["prod_program", "val_program", "file_path_prod", "file_path_valid"]
            sub = _shorten_df(sub, path_cols)

            # Status filter
            statuses = ["All"] + sorted(sub["overall_status"].unique().tolist())
            sel = st.selectbox("Filter by status", statuses, key="filter_{}".format(dom))
            if sel != "All":
                sub = sub[sub["overall_status"] == sel]

            search = st.text_input("Search program name", key="search_{}".format(dom))
            if search:
                sub = sub[sub["program_name"].str.contains(search, case=False, na=False)]

            st.caption("{} programs / outputs".format(len(sub)))

            # --- Column order: program, prod, val, prod user, val user,
            #     THEN status (col 6), THEN independence, timing, compare, counts ---
            if dom == "TFL":
                display_cols = [
                    "program_name",
                    "prod_program",
                    "val_program",
                    "full_name_prod", "userid_prod",
                    "full_name_valid", "userid_valid",
                    "overall_status",
                    "independence",
                    "prod_run_time", "valid_run_time",
                    "prod_output_exists", "val_output_exists",
                    "compare_status",
                    "error_count", "warning_count",
                ]
            else:
                display_cols = [
                    "program_name",
                    "prod_program",
                    "val_program",
                    "full_name_prod", "userid_prod",
                    "full_name_valid", "userid_valid",
                    "overall_status",
                    "independence",
                    "prod_modify_time", "valid_modify_time",
                    "prod_run_time", "valid_run_time",
                    "compare_status",
                    "error_count", "warning_count",
                ]

            show_cols = [c for c in display_cols if c in sub.columns]

            # --- Full row highlight by status ---
            st.dataframe(
                _style_full_rows(sub[show_cols], "overall_status"),
                use_container_width=True,
                hide_index=True,
                height=max(300, min(800, len(sub) * 38 + 50)),
            )

    _show_domain(tab_sdtm, "SDTM")
    _show_domain(tab_adam, "ADAM")
    _show_domain(tab_tfl,  "TFL")

    with tab_issues:
        if iss is None or iss.empty:
            st.success("No issues found.")
        else:
            iss_show = iss[iss["issue_type"] != "COMPARE_CLEAN"].copy() if not iss.empty else iss

            col1, col2, col3 = st.columns(3)
            dom_opts  = ["All"] + sorted(iss_show["domain"].dropna().unique().tolist())     if not iss_show.empty else ["All"]
            type_opts = ["All"] + sorted(iss_show["issue_type"].dropna().unique().tolist()) if not iss_show.empty else ["All"]
            src_opts  = ["All"] + sorted(iss_show["source"].dropna().unique().tolist())     if not iss_show.empty else ["All"]

            sel_dom  = col1.selectbox("Domain",     dom_opts,  key="iss_dom")
            sel_type = col2.selectbox("Issue Type", type_opts, key="iss_type")
            sel_src  = col3.selectbox("Source",     src_opts,  key="iss_src")
            prog_srch = st.text_input("Search program name", key="iss_prog")

            f = iss_show.copy()
            if sel_dom  != "All": f = f[f["domain"]     == sel_dom]
            if sel_type != "All": f = f[f["issue_type"] == sel_type]
            if sel_src  != "All": f = f[f["source"]     == sel_src]
            if prog_srch:
                f = f[f["program_name"].str.contains(prog_srch, case=False, na=False)]

            # Shorten file_path to filename only
            if "file_path" in f.columns:
                f["file_path"] = f["file_path"].apply(
                    lambda x: Path(str(x)).name if x and str(x) not in ("", "nan") else "--"
                )

            st.caption("{} issues".format(len(f)))

            # Full row highlight on issue type
            issue_row_colors_light = {
                "ERROR":        ("#fde8ea", "#721c24"),
                "MISMATCH":     ("#fde8ea", "#721c24"),
                "COMPARE_DIFF": ("#fde8ea", "#721c24"),
                "WARNING":      ("#fffacd", "#856404"),
                "NOTE":         ("", ""),
            }
            issue_row_colors_dark = {
                "ERROR":        ("#200808", "#f85149"),
                "MISMATCH":     ("#200808", "#f85149"),
                "COMPARE_DIFF": ("#200808", "#f85149"),
                "WARNING":      ("#201500", "#d29922"),
                "NOTE":         ("", ""),
            }
            issue_row_colors = issue_row_colors_dark if theme == "dark" else issue_row_colors_light

            def _issue_row_style(row):
                it = str(row.get("issue_type", ""))
                pair = issue_row_colors.get(it, ("", ""))
                bg, text = pair
                if bg:
                    return ["background-color: {}; color: {}".format(bg, text)] * len(row)
                return [""] * len(row)

            try:
                styled_issues = f.style.apply(_issue_row_style, axis=1)
            except Exception:
                styled_issues = f.style

            st.dataframe(
                styled_issues,
                use_container_width=True,
                hide_index=True,
                height=max(300, min(800, len(f) * 38 + 50)),
            )

    # ---- TNF Coverage tab ----
    with tab_tnf:
        tnf_cov = outputs.get("tnf_coverage", pd.DataFrame())
        if tnf_cov is None or tnf_cov.empty:
            st.info(
                ":information_source: No TNF file found in docs/ folder.  \n"
                "The tool looks for any .xlsx file with **tnf** in the filename "
                "(e.g. GS-US-409-5696-tnf-draft.xlsx).  \n"
                "Place it in the **docs/** subfolder of your study root."
            )
        else:
            tnf_file = tnf_cov["tnf_file"].iloc[0] if "tnf_file" in tnf_cov.columns else ""
            total_tnf  = len(tnf_cov)
            present_n  = int((tnf_cov["status"] == "PRESENT").sum())
            missing_n  = int((tnf_cov["status"] == "MISSING").sum())

            st.caption("TNF file: **{}**".format(tnf_file))

            k1, k2, k3 = st.columns(3)
            k1.metric("Total TitleKeys", total_tnf)
            k2.metric("Present in Prod", present_n)
            k3.metric("Missing from Prod", missing_n,
                      delta="-{}".format(missing_n) if missing_n else None,
                      delta_color="inverse")

            st.divider()

            # Filter
            status_opts = ["All", "MISSING", "PRESENT"]
            sel_status = st.selectbox("Filter by status", status_opts, key="tnf_cov_status")
            search_tk = st.text_input("Search TitleKey / description", key="tnf_cov_search")

            disp = tnf_cov.copy()
            if sel_status != "All":
                disp = disp[disp["status"] == sel_status]
            if search_tk:
                mask = (
                    disp["titlekey"].str.contains(search_tk, case=False, na=False) |
                    disp["title1"].str.contains(search_tk, case=False, na=False)
                )
                disp = disp[mask]

            st.caption("{} entries".format(len(disp)))

            show_cols = ["titlekey", "tflt", "tfln", "title1", "status", "matched_outputs"]
            show_cols = [c for c in show_cols if c in disp.columns]

            st.dataframe(
                _style_full_rows(disp[show_cols], "status"),
                use_container_width=True,
                hide_index=True,
                height=max(300, min(900, len(disp) * 38 + 50)),
            )

    st.divider()

    # ---- Export ----
    col_xl, col_csv, col_spacer = st.columns([2, 2, 4])

    if col_xl.button(":page_facing_up: Export Excel + CSV + HTML"):
        with st.spinner("Writing reports..."):
            written = write_reports(outputs, study_paths, cfg)
        for label, fpath in written.items():
            st.success("Written [{}]: {}".format(label, fpath))

    # Inline Excel download
    try:
        import io, tempfile, shutil
        from smart_validation.config import Config as _Cfg

        def _make_excel_bytes():
            tmp = Path(tempfile.mkdtemp())
            tmp_study = type("S", (), {
                "docs":         tmp,
                "study_root":   study_paths.study_root,
                "project_code": study_paths.project_code,
                "study_code":   study_paths.study_code,
            })()
            tmp_cfg = _Cfg(raw={
                "reporting": {
                    "timestamp_in_filenames": False,
                    "write_csv":   False,
                    "write_excel": True,
                    "write_html":  False,
                }
            })
            from smart_validation.report import write_reports as _wr
            w = _wr(outputs, tmp_study, tmp_cfg)
            xl_path = w.get("excel")
            if xl_path and Path(str(xl_path)).exists():
                data = Path(str(xl_path)).read_bytes()
                shutil.rmtree(tmp, ignore_errors=True)
                return data
            shutil.rmtree(tmp, ignore_errors=True)
            return b""

        xl_bytes = _make_excel_bytes()
        if xl_bytes:
            col_csv.download_button(
                label=":inbox_tray: Download Excel",
                data=xl_bytes,
                file_name="Validation_Report_{}.xlsx".format(
                    study_paths.study_code if study_paths else "study"
                ),
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
    except Exception:
        pass


if __name__ == "__main__":
    main()
