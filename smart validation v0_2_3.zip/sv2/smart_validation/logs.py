from __future__ import annotations
from pathlib import Path
import re
import pandas as pd

# ---------------------------------------------------------------------------
# Major actionable patterns (all others ignored for speed)
# Order matters: COMPARE_CLEAN must come before COMPARE_DIFF
# ---------------------------------------------------------------------------
_MAJOR = [
    ("ERROR",         re.compile(r"\bERROR\b\s*:", re.I)),
    ("COMPARE_CLEAN", re.compile(
        r"NOTE:.*(?:No unequal values were found|0 variables have conflicting|all values are identical)",
        re.I)),
    ("COMPARE_DIFF",  re.compile(
        r"NOTE:.*(?:[1-9]\d*\s+variable.*(?:conflicting|unequal)|All\s+variables\s+contain.*conflicting)",
        re.I)),
    ("MISMATCH",      re.compile(r"NOTE:.*MERGE.*repeats of BY values", re.I)),
    ("ERROR",         re.compile(r"NOTE:.*Invalid\s+(?:numeric|character)\s+data", re.I)),
    ("ERROR",         re.compile(r"NOTE:.*[Dd]ivision\s+by\s+zero", re.I)),
    ("ERROR",         re.compile(r"NOTE:.*Lost\s+card", re.I)),
    ("WARNING",       re.compile(r"NOTE:\s+Variable\s+\S+\s+is\s+uninitialized", re.I)),
    ("WARNING",       re.compile(r"NOTE:.*truncated", re.I)),
    ("WARNING",       re.compile(r"WARNING:.*ODS.*still\s+open", re.I)),
    ("WARNING",       re.compile(r"\bWARNING\b\s*:", re.I)),
]

# ---------------------------------------------------------------------------
# Boilerplate lines to skip unconditionally
# ---------------------------------------------------------------------------
_SKIP_RE = re.compile(
    r"^NOTE:\s*(?:"
    r"\d+\s+records?\s+(?:read|written|created|processed)"
    r"|The\s+data\s+set\s+\S+\s+has\s+\d+"
    r"|DATA\s+statement\s+used"
    r"|PROCEDURE\s+\w+\s+used"
    r"|Real\s+time"
    r"|cpu\s+time"
    r"|SAS\s+Institute"
    r"|The\s+SAS\s+System"
    r"|Copyright"
    r"|Character\s+values\s+have\s+been"
    r"|Numeric\s+values\s+have\s+been"
    r"|There\s+were\s+\d+\s+observations"
    r"|The\s+file\s+\S+\s+is"
    r"|Input\s+Data\s+File"
    r"|Output\s+Data\s+File"
    r")",
    re.I,
)

_SAS_DT_RE = re.compile(
    r"(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)"
    r"\s+(\w+\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+\d{4})",
    re.I,
)


def _read_lines(path: Path, nmax: int = 10000):
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for i, line in enumerate(f):
                if i >= nmax:
                    break
                yield line.rstrip("\n")
    except Exception:
        return


def _extract_run_datetime(path: Path, fallback_mtime: float) -> pd.Timestamp:
    for line in _read_lines(path, nmax=30):
        m = _SAS_DT_RE.search(line)
        if m:
            try:
                return pd.to_datetime(m.group(1), format="%B %d %H:%M:%S %Y", utc=True)
            except Exception:
                pass
    return pd.to_datetime(fallback_mtime, unit="s", utc=True)


def analyze_logs(df_logs: pd.DataFrame, max_lines: int = 10000):
    """
    Scan SAS log files for major actionable issues only.

    Captured issue types:
      ERROR         - ERROR: lines, invalid data, division by zero, lost card
      WARNING       - WARNING: lines, uninitialized vars, truncated records
      MISMATCH      - MERGE BY repeat observations
      COMPARE_CLEAN - PROC COMPARE: no differences found
      COMPARE_DIFF  - PROC COMPARE: differences found

    Returns:
        issues_df  [program_name, issue_type, issue_text, file_path, domain, source]
        run_df     [program_name, run_datetime, domain]
    """
    _ecols = ["program_name", "issue_type", "issue_text", "file_path", "domain", "source"]
    _rcols = ["program_name", "run_datetime", "domain"]

    if df_logs is None or df_logs.empty:
        return pd.DataFrame(columns=_ecols), pd.DataFrame(columns=_rcols)

    issue_rows = []
    time_rows = []

    for _, r in df_logs.iterrows():
        p = Path(r["file_path"])
        prog = r["program_name"]
        dom = r["domain"]
        src = r.get("label", "")
        source_label = "PROD_LOG" if "prod" in src else "VAL_LOG"

        run_dt = _extract_run_datetime(p, r["mtime"])
        time_rows.append(dict(program_name=prog, run_datetime=run_dt, domain=dom))

        for line in _read_lines(p, nmax=max_lines):
            stripped = line.strip()
            if not stripped:
                continue
            if _SKIP_RE.match(stripped):
                continue
            for issue_type, pat in _MAJOR:
                if pat.search(line):
                    issue_rows.append(dict(
                        program_name=prog,
                        issue_type=issue_type,
                        issue_text=line[:400].strip(),
                        file_path=str(p),
                        domain=dom,
                        source=source_label,
                    ))
                    break

    return (
        pd.DataFrame(issue_rows) if issue_rows else pd.DataFrame(columns=_ecols),
        pd.DataFrame(time_rows)  if time_rows  else pd.DataFrame(columns=_rcols),
    )
