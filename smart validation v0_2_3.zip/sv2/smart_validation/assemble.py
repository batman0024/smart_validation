from __future__ import annotations

import re
from pathlib import Path as _P
from datetime import timedelta
import pandas as pd

from smart_validation.scanner import scan_dir, normalize_val_stem, is_helper
from smart_validation.author import extract_programmers
from smart_validation.logs import analyze_logs
from smart_validation.lst import analyze_lsts
from smart_validation.tfl_map import tfl_pairs
from smart_validation.tnf import tnf_check
from smart_validation.tnf_coverage import tnf_coverage_check, tnf_extra_outputs

_EMPTY_ISSUES_COLS = [
    "domain", "program_name", "issue_type", "issue_text", "file_path", "source"
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _path_status(p: _P) -> str:
    if not p.exists():
        return "MISSING"
    try:
        next(p.rglob("*.*"))
        return "ACTIVE"
    except StopIteration:
        return "EMPTY"


def _compare_status_for(program: str, domain: str, issues: pd.DataFrame) -> str:
    """
    Derive PROC COMPARE status from the issues table for a given program.
    Returns: CLEAN | DIFFERENCES | NOT RUN
    """
    if issues.empty:
        return "NOT RUN"
    mask = (issues["program_name"] == program) & (issues["domain"] == domain)
    prog_issues = issues.loc[mask, "issue_type"]
    if (prog_issues == "COMPARE_CLEAN").any():
        return "CLEAN"
    if (prog_issues == "COMPARE_DIFF").any():
        return "DIFFERENCES"
    return "NOT RUN"


def _independence(uid_prod, uid_val) -> str:
    # Use pd.isna before casting to avoid "nan" string false-positives
    if pd.isna(uid_prod) or pd.isna(uid_val):
        return "UNKNOWN"
    u1 = str(uid_prod).strip().lower()
    u2 = str(uid_val).strip().lower()
    if not u1 or not u2:
        return "UNKNOWN"
    return "VIOLATION" if u1 == u2 else "OK"


def _mtime(fp) -> "pd.Timestamp":
    """Return UTC-aware mtime for a file path, or NaT if absent/error."""
    try:
        p = _P(str(fp))
        if p.exists():
            return pd.to_datetime(p.stat().st_mtime, unit="s", utc=True)
    except Exception:
        pass
    return pd.NaT


def _overall_status(row: pd.Series, tolerance_hours: float = 0) -> str:
    """Priority-ordered overall status logic."""
    # Helper programs skip all checks
    if row.get("is_helper", False):
        return "Helper - No Validation Required"

    fp = row.get("file_path_prod", "")
    fv = row.get("file_path_valid", "")

    if not fp or str(fp) in ("", "nan"):
        return "Missing Production Program"
    if not fv or str(fv) in ("", "nan"):
        return "Missing Validation Program"

    indep = row.get("independence", "OK")
    if indep == "VIOLATION":
        return "Independence Violation"

    if row.get("error_count", 0) > 0:
        return "Critical Log Error"

    cmp = row.get("compare_status", "NOT RUN")
    if cmp == "DIFFERENCES":
        return "Comparison Differences"

    tol = timedelta(hours=tolerance_hours)
    pm = row.get("prod_modify_time")
    pr = row.get("prod_run_time")
    vm = row.get("valid_modify_time")
    vr = row.get("valid_run_time")

    if pd.notna(pm) and pd.notna(pr) and (pm - pr) > tol:
        return "Prod Modified After Run"
    if pd.notna(vm) and pd.notna(vr) and (vm - vr) > tol:
        return "Val Modified After Run"
    if pd.notna(pr) and pd.notna(vr) and (pr - vr) > tol:
        return "Run Order Issue"

    if row.get("warning_count", 0) > 0:
        return "Warnings Found"
    if cmp == "NOT RUN":
        return "Compare Not Run"

    return "OK"


# ---------------------------------------------------------------------------
# Collect
# ---------------------------------------------------------------------------

def collect(study, cfg) -> dict:
    """Scan all study folders and return raw file DataFrames by area."""
    include_exts = cfg.get("scan", "include_extensions",
                           default=[".sas", ".log", ".lst", ".pdf", ".rtf", ".out"])
    ignore_hidden = bool(cfg.get("scan", "ignore_hidden", default=True))

    return {
        "prod_sdtm": scan_dir(study.prod_sdtm, include_exts, ignore_hidden, label="prod_sdtm"),
        "prod_adam": scan_dir(study.prod_adam, include_exts, ignore_hidden, label="prod_adam"),
        "prod_tfl":  scan_dir(study.prod_tfl,  include_exts, ignore_hidden, label="prod_tfl"),
        "valid":     scan_dir(study.valid,      include_exts, ignore_hidden, label="valid"),
        "tools":     scan_dir(study.tools,      include_exts, ignore_hidden, label="tools"),
    }


# ---------------------------------------------------------------------------
# Assemble SDTM / ADaM
# ---------------------------------------------------------------------------

def _assemble_sdtm_adam(
    programs_prod: pd.DataFrame,
    programs_valid: pd.DataFrame,
    all_issues: pd.DataFrame,
    run_times_prod: pd.DataFrame,
    run_times_valid: pd.DataFrame,
    cfg,
    tolerance_hours: float,
) -> pd.DataFrame:
    helper_sfx  = cfg.get("pairing", "helper_suffixes", default=[]) or []
    helper_prgs = cfg.get("pairing", "helper_programs",  default=[]) or []
    val_pfx     = cfg.get("pairing", "val_prefixes",     default=["v-", "v_"]) or ["v-", "v_"]

    sd_ad_prod = programs_prod[programs_prod["domain"] != "TFL"].copy()
    sd_ad_val  = programs_valid[programs_valid["domain"] != "TFL"].copy()

    # Normalize validation program names by stripping prefix
    sd_ad_val["program_name_norm"] = sd_ad_val["program_name"].apply(
        lambda n: normalize_val_stem(n, val_pfx)
    )

    rows = []
    for _, pr in sd_ad_prod.iterrows():
        prog = pr["program_name"]
        dom  = pr["domain"]
        helper_flag = is_helper(prog, helper_sfx, helper_prgs)

        # Find matching validation row
        val_match = sd_ad_val[
            (sd_ad_val["program_name_norm"].str.lower() == prog.lower()) &
            (sd_ad_val["domain"] == dom)
        ]
        vr = val_match.iloc[0] if not val_match.empty else None

        # Run times
        rtp_match = run_times_prod[
            (run_times_prod["program_name"] == prog) &
            (run_times_prod["domain"] == dom)
        ] if not run_times_prod.empty else pd.DataFrame()
        rtv_match = run_times_valid[
            (run_times_valid["program_name"] == (vr["program_name"] if vr is not None else "")) &
            (run_times_valid["domain"] == dom)
        ] if not run_times_valid.empty and vr is not None else pd.DataFrame()

        prod_run = rtp_match.sort_values("run_datetime", ascending=False).iloc[0]["run_datetime"] \
            if not rtp_match.empty else pd.NaT
        val_run  = rtv_match.sort_values("run_datetime", ascending=False).iloc[0]["run_datetime"] \
            if not rtv_match.empty else pd.NaT

        prod_mod = _mtime(pr["file_path"])
        val_mod  = _mtime(vr["file_path"] if vr is not None else pd.NaT)

        uid_prod  = pr.get("userid", "")
        uid_val   = vr["userid"] if vr is not None else ""
        name_prod = str(pr.get("full_name", ""))
        name_val  = str(vr["full_name"]) if vr is not None else ""

        err_cnt  = int(((all_issues["program_name"] == prog) & (all_issues["domain"] == dom) &
                        (all_issues["issue_type"].isin(["ERROR", "MISMATCH"]))).sum()) \
            if not all_issues.empty else 0
        warn_cnt = int(((all_issues["program_name"] == prog) & (all_issues["domain"] == dom) &
                        (all_issues["issue_type"] == "WARNING")).sum()) \
            if not all_issues.empty else 0

        cmp = _compare_status_for(prog, dom, all_issues)
        indep = _independence(uid_prod, uid_val) if not helper_flag else "N/A"

        rec = dict(
            domain=dom,
            program_name=prog,
            prod_program=pr["file_path"],
            val_program=vr["file_path"] if vr is not None else "",
            full_name_prod=name_prod,
            userid_prod=uid_prod,
            full_name_valid=name_val,
            userid_valid=uid_val,
            independence=indep,
            prod_modify_time=prod_mod,
            valid_modify_time=val_mod,
            prod_run_time=prod_run,
            valid_run_time=val_run,
            file_path_prod=pr["file_path"],
            file_path_valid=vr["file_path"] if vr is not None else "",
            error_count=err_cnt,
            warning_count=warn_cnt,
            compare_status=cmp,
            is_helper=helper_flag,
        )
        rec["overall_status"] = _overall_status(rec, tolerance_hours)
        rows.append(rec)

    return pd.DataFrame(rows) if rows else pd.DataFrame()


# ---------------------------------------------------------------------------
# Assemble TFL
# ---------------------------------------------------------------------------

def _assemble_tfl(
    tfl_pairs_df: pd.DataFrame,
    programs_prod: pd.DataFrame,
    programs_valid: pd.DataFrame,
    all_issues: pd.DataFrame,
    run_times_prod: pd.DataFrame,
    run_times_valid: pd.DataFrame,
    prod_out_files: pd.DataFrame,
    val_out_files: pd.DataFrame,
    cfg,
    tolerance_hours: float,
) -> pd.DataFrame:
    if tfl_pairs_df is None or tfl_pairs_df.empty:
        return pd.DataFrame()

    tfl_prod_map = {}
    if not programs_prod.empty:
        for _, r in programs_prod[programs_prod["domain"] == "TFL"].iterrows():
            tfl_prod_map[r["program_name"].lower()] = r

    tfl_val_map = {}
    if not programs_valid.empty:
        for _, r in programs_valid[programs_valid["domain"] == "TFL"].iterrows():
            tfl_val_map[r["program_name"].lower()] = r

    prod_disk = set()
    if not prod_out_files.empty and "program_name" in prod_out_files.columns:
        prod_disk = set(prod_out_files["program_name"].str.lower().tolist())

    val_disk = set()
    if not val_out_files.empty and "program_name" in val_out_files.columns:
        val_disk = set(val_out_files["program_name"].str.lower().tolist())

    rows = []
    for _, pair in tfl_pairs_df.iterrows():
        output_stem = str(pair.get("output_stem", ""))
        pprog = str(pair.get("prod_program", ""))
        vprog = str(pair.get("valid_program", ""))

        pr = tfl_prod_map.get(pprog.lower())
        vr = tfl_val_map.get(vprog.lower())

        uid_prod  = str(pr["userid"])    if pr is not None else ""
        uid_val   = str(vr["userid"])    if vr is not None else ""
        name_prod = str(pr["full_name"]) if pr is not None else ""
        name_val  = str(vr["full_name"]) if vr is not None else ""

        prod_mod = _mtime(pr["file_path"]) if pr is not None else pd.NaT
        val_mod  = _mtime(vr["file_path"]) if vr is not None else pd.NaT

        # Run times from logs
        rtp_m = run_times_prod[run_times_prod["program_name"] == pprog] \
            if not run_times_prod.empty else pd.DataFrame()
        rtv_m = run_times_valid[run_times_valid["program_name"] == vprog] \
            if not run_times_valid.empty else pd.DataFrame()

        prod_run = rtp_m.sort_values("run_datetime", ascending=False).iloc[0]["run_datetime"] \
            if not rtp_m.empty else pd.NaT
        val_run  = rtv_m.sort_values("run_datetime", ascending=False).iloc[0]["run_datetime"] \
            if not rtv_m.empty else pd.NaT

        prod_file_exists = output_stem.lower() in prod_disk
        val_file_exists  = output_stem.lower() in val_disk

        err_cnt  = int(((all_issues["program_name"] == output_stem) &
                        (all_issues["issue_type"].isin(["ERROR", "MISMATCH"]))).sum()) \
            if not all_issues.empty else 0
        warn_cnt = int(((all_issues["program_name"] == output_stem) &
                        (all_issues["issue_type"] == "WARNING")).sum()) \
            if not all_issues.empty else 0

        # Check compare status using both the program name and output stem
        cmp = _compare_status_for(pprog, "TFL", all_issues)
        if cmp == "NOT RUN" and output_stem:
            cmp = _compare_status_for(output_stem, "TFL", all_issues)
        indep = _independence(uid_prod, uid_val)

        rec = dict(
            domain="TFL",
            program_name=output_stem,
            prod_program=pprog,
            val_program=vprog,
            full_name_prod=name_prod,
            userid_prod=uid_prod,
            full_name_valid=name_val,
            userid_valid=uid_val,
            independence=indep,
            prod_modify_time=prod_mod,
            valid_modify_time=val_mod,
            prod_run_time=prod_run,
            valid_run_time=val_run,
            file_path_prod=pr["file_path"] if pr is not None else "",
            file_path_valid=vr["file_path"] if vr is not None else "",
            prod_output_exists="YES" if prod_file_exists else "NO",
            val_output_exists="YES" if val_file_exists else "NO",
            error_count=err_cnt,
            warning_count=warn_cnt,
            compare_status=cmp,
            is_helper=False,
        )
        rec["overall_status"] = _overall_status(rec, tolerance_hours)
        rows.append(rec)

    return pd.DataFrame(rows) if rows else pd.DataFrame()


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def assemble(parts: dict, study, cfg) -> dict:
    """
    Full assembly: scan results -> final reports.

    Returns dict with keys:
        final_report, all_issues, paths_summary, tfl_pairs,
        programs_tools, tnf_check
    """
    max_lines     = int(cfg.get("scan", "max_log_lines", default=10000))
    tolerance_hrs = float(cfg.get("timing", "run_order_tolerance_hours", default=0))

    # Partition by filetype
    def _q(df, ftype):
        return df[df["filetype"] == ftype] if not df.empty and "filetype" in df.columns \
            else pd.DataFrame(columns=df.columns if not df.empty else [])

    prod_sdtm_sas = _q(parts["prod_sdtm"], "SAS")
    prod_adam_sas = _q(parts["prod_adam"], "SAS")
    prod_tfl_sas  = _q(parts["prod_tfl"],  "SAS")
    valid_sas     = _q(parts["valid"],     "SAS")
    tools_sas     = _q(parts["tools"],     "SAS")

    # Extract programmers
    programs_prod  = pd.concat([
        extract_programmers(prod_sdtm_sas, cfg),
        extract_programmers(prod_adam_sas, cfg),
        extract_programmers(prod_tfl_sas,  cfg),
    ], ignore_index=True)
    programs_valid = extract_programmers(valid_sas, cfg)
    programs_tools = extract_programmers(tools_sas, cfg)

    # Logs
    prod_logs = pd.concat([
        _q(parts["prod_sdtm"], "LOG"),
        _q(parts["prod_adam"], "LOG"),
        _q(parts["prod_tfl"],  "LOG"),
    ], ignore_index=True)
    valid_logs = _q(parts["valid"], "LOG")

    log_issues_prod,  run_times_prod  = analyze_logs(prod_logs,  max_lines)
    log_issues_valid, run_times_valid = analyze_logs(valid_logs, max_lines)
    lst_issues_valid = analyze_lsts(_q(parts["valid"], "LST"))

    all_issues = pd.concat([
        log_issues_prod.assign(source="PROD_LOG"),
        log_issues_valid.assign(source="VAL_LOG"),
        lst_issues_valid,
    ], ignore_index=True)

    for c in _EMPTY_ISSUES_COLS:
        if c not in all_issues.columns:
            all_issues[c] = pd.NA
    all_issues = all_issues[_EMPTY_ISSUES_COLS].copy()

    # TFL pairing
    prod_out = _q(parts["prod_tfl"], "OUT")
    val_out  = _q(parts["valid"],    "OUT")

    tfl_pairs_df = tfl_pairs(
        prod_logs=prod_logs,
        val_logs=valid_logs,
        prod_out=prod_out,
        val_out=val_out,
        cfg=cfg,
        prod_sas=prod_tfl_sas,
        val_sas=valid_sas[valid_sas["domain"] == "TFL"] if not valid_sas.empty else valid_sas,
    )

    # Final reports
    sdtm_adam_report = _assemble_sdtm_adam(
        programs_prod, programs_valid, all_issues,
        run_times_prod, run_times_valid, cfg, tolerance_hrs,
    )

    tfl_report = _assemble_tfl(
        tfl_pairs_df, programs_prod, programs_valid, all_issues,
        run_times_prod, run_times_valid, prod_out, val_out,
        cfg, tolerance_hrs,
    )

    final_report = pd.concat([sdtm_adam_report, tfl_report], ignore_index=True)
    if not final_report.empty:
        final_report = final_report.sort_values(
            ["domain", "overall_status", "program_name"]
        ).reset_index(drop=True)

    # Paths summary
    paths_summary = pd.DataFrame([
        dict(path_type="Production SDTM", path_value=str(study.prod_sdtm), status=_path_status(study.prod_sdtm)),
        dict(path_type="Production ADaM", path_value=str(study.prod_adam), status=_path_status(study.prod_adam)),
        dict(path_type="Production TFL",  path_value=str(study.prod_tfl),  status=_path_status(study.prod_tfl)),
        dict(path_type="Validation",       path_value=str(study.valid),    status=_path_status(study.valid)),
        dict(path_type="Tools",            path_value=str(study.tools),    status=_path_status(study.tools)),
        dict(path_type="TNF Excel",        path_value=str(study.docs / "tnf.xlsx"),
             status="ACTIVE" if (study.docs / "tnf.xlsx").exists() else "MISSING"),
    ])

    tools_simple = pd.DataFrame(columns=["program_name", "file_path", "modify_time"])
    if not programs_tools.empty:
        tools_simple = programs_tools[["program_name", "file_path", "mtime"]].rename(
            columns={"mtime": "modify_time"}
        )

    # Collect prod TFL output stems for TNF coverage check
    _prod_tfl_stems = []
    if not tfl_pairs_df.empty and "prod_program" in tfl_pairs_df.columns:
        # Use output_stem column (the actual output names)
        if "output_stem" in tfl_pairs_df.columns:
            _prod_tfl_stems = [
                s for s in tfl_pairs_df["output_stem"].dropna().tolist()
                if s and str(s) not in ("", "nan")
            ]
    # Also add any prod OUT files from disk scan not captured by tfl_pairs
    if not prod_out.empty and "program_name" in prod_out.columns:
        for s in prod_out["program_name"].dropna().tolist():
            if s and str(s) not in ("", "nan") and s not in _prod_tfl_stems:
                _prod_tfl_stems.append(str(s))

    _tnf_coverage = tnf_coverage_check(study, cfg, _prod_tfl_stems)

    return {
        "final_report":   final_report,
        "all_issues":     all_issues,
        "paths_summary":  paths_summary,
        "tfl_pairs":      tfl_pairs_df,
        "programs_tools": tools_simple,
        "tnf_check":      tnf_check(study, cfg),
        "tnf_coverage":   _tnf_coverage,
    }
